# Code and Data — AI-Assisted Supervisory Energy Management for a PV-BESS Microgrid via a Solid-State Transformer Grid Interface

This repository contains the simulation code, real irradiance/power data, result summaries, and trained model checkpoints behind the manuscript submitted to *Applied Energy* (Elsevier):

> Shahbaz, "AI-Assisted Supervisory Energy Management for a PV-BESS Microgrid via a Solid-State Transformer Grid Interface."

It is provided to satisfy the journal's Data/Code Availability requirement. Everything needed to reproduce every number, table, and figure in the manuscript is here, except for large regenerable trace files, which are intentionally omitted (see "What is not included" below).

## Repository layout

```
code/         15 Python scripts (simulation, training, analysis, plotting)
data/         2 real NREL solar data CSVs
results/      12 JSON result summaries (the numbers actually reported in the paper)
checkpoints/  2 trained DQN model weights (.pt, PyTorch)
```

## What each script does, and which paper section it supports

| Script | Produces | Paper section |
|---|---|---|
| `sapec_sim.py` | `sim_metrics.json`; shared simulation core (microgrid model, DQN training loop, PI baseline) imported by most other scripts | Section 3 (baseline microgrid + PI/DQN energy management) |
| `sst_dab_model.py` | `sst_dab_results.json` | Section 4.2 (Dual-Active-Bridge stage, switching-resolution verification) |
| `sst_chb_model.py` | `sst_chb_results.json` | Section 4.1 (Cascaded H-Bridge stage, switching-resolution verification) |
| `sst_losses.py` | `sst_losses_results.json` | Section 5 (efficiency and thermal loss modeling, 94.3% full-SST efficiency figure) |
| `sst_sim.py` | `sst_sag_results.json` | Section 6.1–6.2 (single-event grid-sag ride-through, SST vs. conventional) |
| `sst_real_profiles.py` | (loads `data/nrel_srrl_bms_ghi_20220120.csv`; prints resampled event fractions used by `sst_montecarlo.py`) | Section 6.5 methodology (real-data-driven PV cloud-transient magnitudes) |
| `sst_montecarlo.py` | `sst_montecarlo_results.json` | Section 6.5 (500-trial Monte Carlo ride-through sweep; 56.6% spared-trip rate, 1.2% vs. 57.8% trip-rate figures) |
| `sst_balancing.py` | `sst_balancing_results.json` | Section 7 (closed-loop active cell-balancing controller, PI gains, convergence time) |
| `sst_thermal_transient.py` | `sst_thermal_transient_results.json` | Section 6.3 / Limitations (dynamic thermal-transient response to a full-interruption event) |
| `sst_dqn_joint.py` | `sst_dqn_joint_results.json` | Section 6.4 (frozen-checkpoint DQN evaluated jointly across SST and conventional interfaces) |
| `sst_dqn_train_sst_aware.py` | `checkpoints/sst_dqn_sst_aware.pt` (+ a training-curve `.npz`, not included — see below) | Section 6.6 methodology (SST-aware DQN retraining) |
| `sst_dqn_compare.py` | `sst_dqn_compare_results.json` | Section 6.6, **Table 7** (frozen vs. SST-aware-retrained DQN: RMSE, battery throughput/EFC, peak slew) |
| `sst_economics.py` | `sst_economics_results.json` | Section 6.7, **Table 8** (techno-economic breakeven: capital premium, avoided-trip value, efficiency-penalty cost) |
| `sst_plots.py` | `fig_*.png` (all manuscript simulation figures) | Figs. 4–12 |
| `sst_graphical_abstract.py` | `fig_graphical_abstract.png` | Graphical Abstract |

`results/sst_dqn_general_perf_compare.json` is a general-operation (non-sag-event) RMSE/cost breakdown for the frozen vs. SST-aware-retrained checkpoints, by evaluation segment (normal, PV-disturbance, load-disturbance, SOC-boundary, grid-disturbance). It was produced by an ad-hoc analysis pass over the two checkpoints' `evaluate_joint()` output rather than a standalone script; every number in it is already folded into the manuscript's Table 7 and Section 6.6 discussion, so it is included for transparency but is not needed to reproduce a paper figure on its own — running `sst_dqn_compare.py` reproduces the same underlying comparison.

`checkpoints/sst_dqn_reused.pt` is the original frozen DQN checkpoint (trained on the conventional-interface microgrid model, `seed=7`, via `sapec_sim.train_dqn()`), reused unmodified as the OOD-stress-test baseline in Section 6.6. `checkpoints/sst_dqn_sst_aware.pt` is the retrained checkpoint produced by `sst_dqn_train_sst_aware.py` (identical architecture, hyperparameters, and `seed=7`, but with the SST's `mv_link_step()` physics injected into the `grid_disturbance` training segment).

## Data provenance

- `data/nrel_srrl_bms_ghi_20220120.csv` — one day (20 Jan 2022) of 1-minute global horizontal irradiance (GHI) measurements from NREL's Solar Radiation Research Laboratory (SRRL) Baseline Measurement System (BMS), Golden, CO.
- `data/nrel_serf_east_1min_ac_power.csv` — one day of 1-minute AC power output from NREL's Solar Energy Research Facility (SERF), east-facing array.

Both were retrieved via the [`pvanalytics`](https://pypi.org/project/pvanalytics/) package's NREL data-access utilities (BSD-3-Clause licensed, NREL-affiliated; `pvanalytics==0.2.2` at time of retrieval). `pvanalytics` is not a runtime dependency of any script in this repository — it was used once, upstream, to pull these two CSVs, which are checked in directly. NREL measurement data of this kind is public domain / open access.

**Disclosed limitation (already stated in the manuscript, Sections 6.5 and 8):** these are 1-minute-resolution measurements from a single day containing 14 identifiable cloud-transient events. The Monte Carlo sweep in `sst_montecarlo.py` resamples real transient *magnitudes* from this dataset; transient *durations* and the load-side profile remain synthetic uniform draws. This is a real-data-informed stress test, not a multi-year, sub-second-resolution empirical dataset — reproducers should not expect finer temporal resolution than 1 minute from the source data itself (the simulation itself runs at switching/control resolution; only the sampled irradiance magnitudes are 1-minute).

## How to reproduce

All scripts are standalone (`python3 script.py`) and write their outputs to the current working directory. Run from inside `code/`.

Recommended order (later scripts depend on earlier scripts' saved JSON/checkpoint outputs; scripts not listed as dependent can be run independently and in any order):

1. `python3 sapec_sim.py` — builds the baseline microgrid model and trains/evaluates the original PI and DQN energy managers (produces `sim_metrics.json`, and `checkpoints/sst_dqn_reused.pt`'s underlying training if regenerating from scratch — note the checkpoint is already included, so this step is only needed to regenerate it from zero).
2. `python3 sst_dab_model.py`, `python3 sst_chb_model.py` — power-electronics switching-resolution verification (independent of each other and of step 1).
3. `python3 sst_losses.py` — efficiency/loss modeling (depends on the DAB/CHB parameter sets defined inline; does not require steps 1–2 to have been run first).
4. `python3 sst_sim.py` — single grid-sag ride-through event, SST vs. conventional.
5. `python3 sst_real_profiles.py` — loads and resamples the real NREL GHI/AC-power CSVs from `data/`; prints the fractional-deficit event distribution consumed by step 6.
6. `python3 sst_montecarlo.py` — 500-trial Monte Carlo ride-through sweep (imports `sst_real_profiles.py`).
7. `python3 sst_economics.py` — techno-economic analysis (reads `sst_montecarlo_results.json` from step 6).
8. `python3 sst_balancing.py` — closed-loop active cell-balancing controller.
9. `python3 sst_thermal_transient.py` — dynamic thermal-transient response.
10. `python3 sst_dqn_joint.py` — evaluates the frozen DQN checkpoint (`checkpoints/sst_dqn_reused.pt`) jointly across both grid interfaces.
11. `python3 sst_dqn_train_sst_aware.py` — retrains the SST-aware DQN (`seed=7`; ~260 episodes). Produces `checkpoints/sst_dqn_sst_aware.pt` (already included — this step is only needed to regenerate it) and a training-curve `.npz` (not included; see below).
12. `python3 sst_dqn_compare.py` — loads both checkpoints from `checkpoints/` and produces the frozen-vs-retrained comparison in `sst_dqn_compare_results.json` (Table 7).
13. `python3 sst_plots.py` — regenerates all manuscript figures from the JSON/checkpoint outputs of the steps above.
14. `python3 sst_graphical_abstract.py` — regenerates the Graphical Abstract figure.

Each script also prints a human-readable summary of its own results to stdout when run.

## What is not included, and why

The full simulation working directory also contains several large `.npz` binary trace/waveform files (switching-resolution current/voltage traces, per-episode training logs, Monte Carlo per-trial raw arrays). These are excluded from this repository because:

- They are large (several are multiple megabytes; one unrelated file from a different project in the same working directory is 462 MB) and are not needed to verify any number reported in the manuscript — the small JSON files in `results/` already contain every summary statistic the paper cites.
- They are fully regenerable, byte-for-byte reproducible (given the fixed random seeds used throughout, `seed=7` for all DQN-related runs), by simply running the corresponding script above.

If a reviewer needs a specific raw trace file for closer inspection, the corresponding author can regenerate and provide it on request.

## Dependencies

See `requirements.txt`. Developed and run with Python 3.11. `torch` is only required by `sapec_sim.py`, `sst_dqn_joint.py`, `sst_dqn_train_sst_aware.py`, and `sst_dqn_compare.py` (the DQN training/evaluation scripts); a CPU-only PyTorch install is sufficient to reproduce all reported results (no GPU-specific code paths are used).

## License

Code is released under the MIT License (see `LICENSE`). The NREL data files in `data/` are public-domain U.S. government measurement data; see the provenance note above.

## Contact

Shahbaz, Power System Lab, Department of Electrical Engineering, K.K. University, Nalanda, Bihar, India — shahbazsauby@gmail.com
