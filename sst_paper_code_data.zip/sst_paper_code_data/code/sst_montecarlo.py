"""
SST paper -- Monte Carlo comparative analysis (Section VI-E): broadens the
fixed-60kW-step + 2-coincident-trace evaluation (sst_sim.py) into a real
statistical distribution of randomized weather (PV cloud-transient),
load-pickup, and MV grid-sag disturbance profiles, run against BOTH
interfaces (conventional LFT+VSC and the proposed SST) at the SAME
evaluate_sag()/coincident_pv_load_profile() machinery already built and
verified in sst_sim.py -- no new interface physics, only a randomized
DRIVER over the existing, already-validated evaluation function.

Randomization ranges (all disclosed, none reverse-fitted to favor either
interface):
  - sag depth:        Uniform(0.10, 1.00)   (10%-100% MV voltage loss)
  - sag duration:      Uniform(0.05, 1.50) s  (50 ms - 1.5 s, spanning the
                        shallow/moderate/full-interruption range already
                        used in the fixed-scenario table)
  - sag start time:    Uniform(0.3, 0.8) s within the evaluation window
                        (kept away from t=0 so the settle pre-roll always
                        completes first)
  - PV cloud-transient: Bernoulli(0.7) chance of occurring at all (30% of
                        trials see NO coincident PV event, matching real
                        operation where not every grid event coincides with
                        a cloud transient); MAGNITUDE now drawn from
                        sst_real_profiles.sample_pv_drop_fraction() -- a
                        bootstrap resample of 14 REAL, measured fractional
                        irradiance-deficit events from NREL SRRL BMS 1-min
                        GHI data (20 Jan 2022), scaled by the same 40 kW
                        ceiling used before (REVISION: replaces the
                        earlier Uniform(0,1) fractional assumption with an
                        empirical one; see sst_real_profiles.py for full
                        methodology and disclosed limitations -- native
                        1-min resolution, single-day sample, ramp
                        DURATION still Uniform(0.05, 0.30) s since this
                        test's coincidence window is sub-second regardless
                        of the source data's own timescale).
  - load pickup:        Bernoulli(0.7) chance of occurring; magnitude
                        Uniform(0, 25) kW, delay after sag start
                        Uniform(0.0, 0.20) s -- UNCHANGED: no comparably
                        accessible real sub-minute customer load dataset
                        was reachable from this environment (see
                        sst_real_profiles.py's docstring), so this side
                        remains the paper's original disclosed synthetic
                        model, a disclosed asymmetry rather than a silent
                        omission.

500 independent trials (seeded, reproducible) are drawn; each trial is
scored on BOTH interfaces using the exact same evaluate_sag() call used
for the fixed scenarios, so a trial that would trip the conventional
interface is not silently excluded -- trip rate itself is one of the
reported statistics.
"""
import numpy as np
import json
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from sst_sim import evaluate_sag, P_STEP_W, V1_NOM  # noqa: E402
from sst_real_profiles import sample_pv_drop_fraction  # noqa: E402

N_TRIALS = 500
SEED = 20260817


def make_trial_profile(rng, sag_start, pv_on, pv_drop_w, pv_ramp_s,
                        load_on, load_pickup_w, load_delay_s):
    def p_in_fn(t):
        p = P_STEP_W
        te = t - sag_start
        if te < 0:
            return p
        if pv_on:
            ramp_frac = min(te / pv_ramp_s, 1.0) if pv_ramp_s > 0 else 1.0
            p -= pv_drop_w * ramp_frac
        if load_on and te >= load_delay_s:
            p -= load_pickup_w
        return p
    return p_in_fn


def draw_trial(rng):
    sag_depth = float(rng.uniform(0.10, 1.00))
    sag_dur = float(rng.uniform(0.05, 1.50))
    sag_start = float(rng.uniform(0.3, 0.8))
    pv_on = bool(rng.random() < 0.7)
    pv_drop_w = sample_pv_drop_fraction(rng) * 40e3 if pv_on else 0.0
    pv_ramp_s = float(rng.uniform(0.05, 0.30))
    load_on = bool(rng.random() < 0.7)
    load_pickup_w = float(rng.uniform(0, 25e3)) if load_on else 0.0
    load_delay_s = float(rng.uniform(0.0, 0.20))
    return dict(sag_depth=sag_depth, sag_dur=sag_dur, sag_start=sag_start,
                pv_on=pv_on, pv_drop_w=pv_drop_w, pv_ramp_s=pv_ramp_s,
                load_on=load_on, load_pickup_w=load_pickup_w,
                load_delay_s=load_delay_s)


def run_trial(trial):
    p_fn = make_trial_profile(None, trial["sag_start"], trial["pv_on"],
                               trial["pv_drop_w"], trial["pv_ramp_s"],
                               trial["load_on"], trial["load_pickup_w"],
                               trial["load_delay_s"])
    seg_len = max(2.0, trial["sag_start"] + trial["sag_dur"] + 0.8)
    out = {}
    for iface in ["conventional", "sst"]:
        metrics, _ = evaluate_sag(iface, trial["sag_depth"], trial["sag_dur"],
                                   sag_start=trial["sag_start"], seg_len=seg_len,
                                   p_in_fn=p_fn)
        out[iface] = metrics
    return out


if __name__ == "__main__":
    rng = np.random.default_rng(SEED)
    trials = [draw_trial(rng) for _ in range(N_TRIALS)]

    results = []
    for k, trial in enumerate(trials):
        r = run_trial(trial)
        results.append(dict(trial=trial, conventional=r["conventional"], sst=r["sst"]))
        if (k + 1) % 100 == 0:
            print(f"  {k+1}/{N_TRIALS} trials complete")

    conv_tripped = np.array([r["conventional"]["tripped"] for r in results])
    sst_tripped = np.array([r["sst"]["tripped"] for r in results])
    sst_dev = np.array([r["sst"]["vdc_max_dev_pct"] for r in results])
    sst_v1min = np.array([r["sst"]["V1_min_pu"] for r in results])
    conv_dev = np.array([r["conventional"]["vdc_max_dev_pct"] for r in results])
    sag_depths = np.array([r["trial"]["sag_depth"] for r in results])
    sag_durs = np.array([r["trial"]["sag_dur"] for r in results])

    conv_trip_rate = float(np.mean(conv_tripped)) * 100
    sst_trip_rate = float(np.mean(sst_tripped)) * 100

    sst_dev_untripped = sst_dev[~sst_tripped]
    percentiles = [50, 90, 95, 99]
    sst_dev_pcts = {p: round(float(np.percentile(sst_dev_untripped, p)), 4) for p in percentiles}

    # Among trials the SST rides through (not tripped), how deep/long was
    # the worst one it still survived, vs. the worst one that tripped it --
    # characterizes the boundary empirically rather than just quoting the
    # single analytic T_HOLD figure.
    if np.any(sst_tripped):
        tripped_durs = sag_durs[sst_tripped]
        tripped_depths = sag_depths[sst_tripped]
        min_tripping_dur = float(np.min(tripped_durs))
    else:
        min_tripping_dur = None
    survived_durs = sag_durs[~sst_tripped]
    max_survived_dur = float(np.max(survived_durs)) if len(survived_durs) else None

    # Both-tripped vs SST-only-survives breakdown (the key comparative claim)
    both_trip = int(np.sum(conv_tripped & sst_tripped))
    conv_only_trips = int(np.sum(conv_tripped & ~sst_tripped))
    neither_trips = int(np.sum(~conv_tripped & ~sst_tripped))
    sst_only_trips = int(np.sum(~conv_tripped & sst_tripped))  # sanity check, should be ~0

    summary = dict(
        n_trials=N_TRIALS, seed=SEED,
        conventional_trip_rate_pct=round(conv_trip_rate, 2),
        sst_trip_rate_pct=round(sst_trip_rate, 2),
        sst_dev_pct_percentiles_untripped=sst_dev_pcts,
        sst_dev_pct_max_untripped=round(float(np.max(sst_dev_untripped)), 4) if len(sst_dev_untripped) else None,
        n_both_trip=both_trip, n_conventional_only_trips=conv_only_trips,
        n_neither_trips=neither_trips, n_sst_only_trips=sst_only_trips,
        min_sag_duration_s_that_tripped_sst=round(min_tripping_dur, 3) if min_tripping_dur else None,
        max_sag_duration_s_sst_survived=round(max_survived_dur, 3) if max_survived_dur else None,
    )
    print(json.dumps(summary, indent=2))

    with open("sst_montecarlo_results.json", "w") as f:
        json.dump(summary, f, indent=2)
    np.savez("sst_montecarlo_raw.npz",
             sag_depth=sag_depths, sag_dur=sag_durs,
             conv_tripped=conv_tripped, sst_tripped=sst_tripped,
             sst_dev_pct=sst_dev, conv_dev_pct=conv_dev, sst_v1min_pu=sst_v1min)
    print("\nSaved sst_montecarlo_results.json and sst_montecarlo_raw.npz")
