"""Figures for the SST paper, matching the style of the prior digest's own
plotting scripts (plots.py, vsc_plots.py, converter_plots.py)."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 9, "figure.dpi": 150})

# ---------------------------------------------------------------------
# Fig. A: DAB waveform at rated operating point (d=0.35)
# ---------------------------------------------------------------------
d = np.load("sst_dab_waveform.npz")
t, i, v1, v2 = d["t"], d["i"], d["v1"], d["v2"]
t0 = t[0]
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5, 4.2), sharex=True)
ax1.step((t - t0) * 1e6, v1 / 1e3, where="post", label=r"$v_1$ (primary)", lw=1.2)
ax1.step((t - t0) * 1e6, v2 / 1e3, where="post", label=r"$v_2'$ (secondary, referred)", lw=1.2, ls="--")
ax1.set_ylabel("Bridge voltage (kV)")
ax1.legend(loc="upper right", fontsize=7)
ax1.grid(alpha=0.3)
ax2.plot((t - t0) * 1e6, i, color="tab:red", lw=1.2)
ax2.set_ylabel("Leakage current (A)")
ax2.set_xlabel(r"Time ($\mu$s)")
ax2.grid(alpha=0.3)
fig.suptitle("DAB cell waveforms at rated operating point (d=0.35)", fontsize=9)
fig.tight_layout()
fig.savefig("fig_dab_waveform.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. B: DAB power transfer -- analytic vs. simulated, plus ZVS region
# ---------------------------------------------------------------------
import json
dab_res = json.load(open("sst_dab_results.json"))
ds = sorted(float(k) for k in dab_res["sweep"].keys())
analytic = [dab_res["sweep"][f"{k}"]["analytic_kW"] if f"{k}" in dab_res["sweep"] else None for k in ds]
# keys were stored as float d in dict from python (loaded back as str repr); handle directly
sweep = dab_res["sweep"]
ds = sorted(float(k) for k in sweep.keys())
analytic = [sweep[str(k) if str(k) in sweep else [kk for kk in sweep if abs(float(kk)-k)<1e-9][0]] for k in ds]
# simpler: rebuild directly
ds = []
an = []
si = []
for k, v in sweep.items():
    ds.append(float(k)); an.append(v["analytic_kW"]); si.append(v["simulated_kW"])
order = np.argsort(ds)
ds = np.array(ds)[order]; an = np.array(an)[order]; si = np.array(si)[order]

fig, ax = plt.subplots(figsize=(4.3, 3.3))
ax.plot(ds, an, "o-", label="Analytic", lw=1.2)
ax.plot(ds, si, "x--", label="Switched-model simulation", lw=1.2)
ax.axvline(dab_res["d_rated"], color="gray", ls=":", lw=1, label=f"Rated d={dab_res['d_rated']}")
ax.set_xlabel("Duty / phase-shift ratio, d")
ax.set_ylabel("Per-cell power transfer (kW)")
ax.legend(fontsize=7)
ax.grid(alpha=0.3)
ax.set_title("DAB power transfer: analytic vs. switched simulation")
fig.tight_layout()
fig.savefig("fig_dab_power.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. C: CHB multilevel waveform (2 fundamental cycles) + spectrum
# ---------------------------------------------------------------------
c = np.load("sst_chb_waveform.npz")
t, ig, vstack, vgrid = c["t"], c["ig"], c["vstack"], c["vgrid"]
mask = t > (t[-1] - 2 / 50.0)
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5, 4.4))
ax1.plot(t[mask] * 1e3, vstack[mask] / 1e3, label="CHB stack output (7-level)", lw=1.0)
ax1.plot(t[mask] * 1e3, vgrid[mask] / 1e3, label="Grid phase voltage", lw=1.2, ls="--")
ax1.set_xlabel("Time (ms)")
ax1.set_ylabel("Voltage (kV)")
ax1.legend(fontsize=7, loc="upper right")
ax1.grid(alpha=0.3)

freqs, mag = c["freqs"], c["mag"]
harmonic_orders = freqs / 50.0
hmask = (harmonic_orders > 0.5) & (harmonic_orders < 60)
il = json.load(open("sst_chb_results.json"))["I_rated_A"]
ax2.stem(harmonic_orders[hmask], 100 * mag[hmask] / il, basefmt=" ", markerfmt=".", linefmt="tab:red")
ax2.set_xlabel("Harmonic order (x 50 Hz)")
ax2.set_ylabel("% of rated current $I_L$")
ax2.set_yscale("log")
ax2.grid(alpha=0.3)
fig.suptitle("CHB MV-side stack waveform and current spectrum", fontsize=9)
fig.tight_layout()
fig.savefig("fig_chb_waveform.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. D: sag ride-through comparison -- Vdc (both interfaces) and V1 (SST)
# ---------------------------------------------------------------------
s = np.load("sst_sag_logs.npz")
scenario = "full_interrupt_long"
tS = s[f"{scenario}_sst_t"]
vdcS = s[f"{scenario}_sst_vdc"]
V1S = s[f"{scenario}_sst_V1"]
tC = s[f"{scenario}_conventional_t"]
vdcC = s[f"{scenario}_conventional_vdc"]
gfS = s[f"{scenario}_sst_grid_frac"]

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5.2, 4.6), sharex=True)
ax1.plot(tC, vdcC, label="Conventional (LFT + VSC)", color="tab:red", lw=1.4)
ax1.plot(tS, vdcS, label="Proposed SST", color="tab:blue", lw=1.4)
ax1.axhspan(800 * 0.8, 800 * 1.2, color="gray", alpha=0.08)
ax1.set_ylabel("LV DC bus $V_{dc}$ (V)")
ax1.legend(fontsize=7, loc="lower left")
ax1.grid(alpha=0.3)
ax2b = ax2.twinx()
ax2.plot(tS, V1S, color="tab:green", lw=1.2, label="MV DC-link $V_1$ (SST)")
ax2.axhline(2805, color="tab:green", ls=":", lw=1)
ax2b.plot(tS, gfS, color="gray", lw=1.0, ls="--", label="Grid availability fraction")
ax2.set_ylabel("$V_1$ (V)", color="tab:green")
ax2b.set_ylabel("Grid available fraction", color="gray")
ax2.set_xlabel("Time (s)")
ax2.grid(alpha=0.3)
fig.suptitle("500 ms full MV interruption (> 453 ms ride-through budget), 60 kW step", fontsize=8.5)
fig.tight_layout()
fig.savefig("fig_sag_ridethrough.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. E: coincident PV/load disturbance overlapping the same 500 ms full
# MV interruption -- Vdc (both interfaces) plus the net LV-bus deficit
# p_in_w that is now ramping/stepping rather than a flat 60 kW.
# ---------------------------------------------------------------------
scenario2 = "coincident_full_interrupt"
tS2 = s[f"{scenario2}_sst_t"]
vdcS2 = s[f"{scenario2}_sst_vdc"]
V1S2 = s[f"{scenario2}_sst_V1"]
pinS2 = s[f"{scenario2}_sst_p_in_w"]
tC2 = s[f"{scenario2}_conventional_t"]
vdcC2 = s[f"{scenario2}_conventional_vdc"]

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5.2, 4.6), sharex=True)
ax1.plot(tC2, vdcC2, label="Conventional (LFT + VSC)", color="tab:red", lw=1.4)
ax1.plot(tS2, vdcS2, label="Proposed SST", color="tab:blue", lw=1.4)
ax1.axhspan(800 * 0.8, 800 * 1.2, color="gray", alpha=0.08)
ax1.set_ylabel("LV DC bus $V_{dc}$ (V)")
ax1.legend(fontsize=7, loc="lower left")
ax1.grid(alpha=0.3)
ax2.plot(tS2, -pinS2 / 1e3, color="tab:purple", lw=1.2)
ax2.set_ylabel("Net LV-bus deficit (kW)")
ax2.set_xlabel("Time (s)")
ax2.grid(alpha=0.3)
fig.suptitle("500 ms full MV interruption coincident with a PV cloud transient\n"
             "+ load pickup (60→100 kW deficit), vs. the fixed-step case", fontsize=8.5)
fig.tight_layout()
fig.savefig("fig_coincident_ridethrough.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. F: Monte Carlo comparative sweep (Section VI-E) -- sag depth vs.
# duration scatter colored by trip outcome (both interfaces), plus a
# histogram of the SST's max deviation among trials it rides through.
# ---------------------------------------------------------------------
mc = np.load("sst_montecarlo_raw.npz")
depth, dur = mc["sag_depth"], mc["sag_dur"]
conv_trip, sst_trip = mc["conv_tripped"].astype(bool), mc["sst_tripped"].astype(bool)
sst_dev = mc["sst_dev_pct"]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2))
ax1.scatter(dur[~conv_trip & ~sst_trip], depth[~conv_trip & ~sst_trip],
            s=10, c="tab:green", label="neither trips", alpha=0.6)
ax1.scatter(dur[conv_trip & ~sst_trip], depth[conv_trip & ~sst_trip],
            s=10, c="tab:orange", label="conventional trips only", alpha=0.6)
ax1.scatter(dur[conv_trip & sst_trip], depth[conv_trip & sst_trip],
            s=14, c="tab:red", marker="x", label="both trip")
ax1.set_xlabel("Sag duration (s)")
ax1.set_ylabel("Sag depth (fraction)")
ax1.legend(fontsize=6, loc="lower right")
ax1.grid(alpha=0.3)
ax1.set_title("500 randomized trials", fontsize=8.5)

sst_dev_ok = sst_dev[~sst_trip]
ax2.hist(sst_dev_ok, bins=40, color="tab:blue", alpha=0.8)
ax2.set_xlabel("SST max LV-bus deviation (%), untripped trials")
ax2.set_ylabel("Trial count")
ax2.set_yscale("log")
ax2.grid(alpha=0.3)
ax2.set_title("Deviation distribution (SST)", fontsize=8.5)
fig.suptitle("Monte Carlo sweep: randomized sag depth/duration + coincident PV/load", fontsize=9)
fig.tight_layout()
fig.savefig("fig_montecarlo.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. G: Foster-network junction-temperature step response (Section VI-C
# electro-thermal extension) for the CHB IGBT, DAB primary IGBT, and DAB
# secondary SiC MOSFET, at each device's own converged average loss.
# ---------------------------------------------------------------------
th = np.load("sst_thermal_step.npz")
fig, ax = plt.subplots(figsize=(4.4, 3.3))
ax.plot(th["t"], th["dtj_chb"], label="CHB cell IGBT", lw=1.3)
ax.plot(th["t"], th["dtj_dab_igbt"], label="DAB primary IGBT", lw=1.3)
ax.plot(th["t"], th["dtj_dab_sic"], label="DAB secondary SiC (qualitative)", lw=1.3, ls="--")
ax.set_xlabel("Time after loss step (s)")
ax.set_ylabel(r"$\Delta T_j$ above case temperature (degC)")
ax.legend(fontsize=7)
ax.grid(alpha=0.3)
ax.set_title("Foster-network junction-temperature step response", fontsize=8.5)
fig.tight_layout()
fig.savefig("fig_thermal_step.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. H: closed-loop active cell-balancing (Section VII extension) --
# open-loop (unbounded drift) vs. closed-loop (converged) V1 trajectories
# for all 9 cells, same random per-cell mismatch draw in both panels.
# ---------------------------------------------------------------------
bal = np.load("sst_balancing_traces.npz")
t_ol, V1_ol, t_cl, V1_cl = bal["t_ol"], bal["V1_ol"], bal["t_cl"], bal["V1_cl"]
# The open-loop trace is only physically meaningful up to the point a real
# cell would already have tripped/been bypassed (the 15% band, and well
# before any cell's link approaches 0V, where this reduced-order C*dV/dt
# abstraction itself breaks down, dividing by a near-zero V1). Plotted only
# out to 16s -- well past the worst cell's 15%-deviation trip point -- to
# show the genuine unbounded-divergence finding without that later
# numerical artifact of the simplified model.
cutoff_ol = int(16.0 / (t_ol[1] - t_ol[0]))
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.2, 3.2), sharey=True)
for c in range(V1_ol.shape[1]):
    ax1.plot(t_ol[:cutoff_ol], V1_ol[:cutoff_ol, c], lw=0.9)
ax1.axhspan(3300 * 0.85, 3300 * 1.15, color="gray", alpha=0.10)
ax1.set_xlabel("Time (s)")
ax1.set_ylabel("Per-cell MV link $V_1$ (V)")
ax1.set_title("Open loop (no balancing)", fontsize=8.5)
ax1.grid(alpha=0.3)
for c in range(V1_cl.shape[1]):
    ax2.plot(t_cl[:3000], V1_cl[:3000, c], lw=0.9)
ax2.set_xlabel("Time (s)")
ax2.set_title("Closed loop (active balancing)", fontsize=8.5)
ax2.grid(alpha=0.3)
fig.suptitle("9-cell fleet, same random per-cell power-sharing mismatch (up to +-3%)", fontsize=9)
fig.tight_layout()
fig.savefig("fig_balancing.png")
plt.close(fig)

# ---------------------------------------------------------------------
# Fig. I: joint DQN/PI x conventional/SST evaluation (Section VI-F) --
# Vdc during the shared 2 s full MV interruption, all four combinations.
# ---------------------------------------------------------------------
dj = np.load("sst_dqn_joint_logs.npz")
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5.2, 4.8), sharex=True)
for key, color, ls in [("conventional_pi", "tab:red", "-"), ("conventional_dqn", "tab:red", "--"),
                        ("sst_pi", "tab:blue", "-"), ("sst_dqn", "tab:blue", "--")]:
    t = dj[f"{key}_t"]
    vdc = dj[f"{key}_vdc"]
    label = key.replace("_", ", ")
    ax1.plot(t, vdc, color=color, ls=ls, lw=1.2, label=label)
ax1.axhspan(800 * 0.8, 800 * 1.2, color="gray", alpha=0.08)
ax1.set_ylabel("LV DC bus $V_{dc}$ (V)")
ax1.legend(fontsize=6.5, loc="lower left", ncol=2)
ax1.grid(alpha=0.3)
for key, color, ls in [("conventional_pi", "tab:red", "-"), ("conventional_dqn", "tab:red", "--"),
                        ("sst_pi", "tab:blue", "-"), ("sst_dqn", "tab:blue", "--")]:
    t = dj[f"{key}_t"]
    pbess = dj[f"{key}_pbess"]
    ax2.plot(t, pbess, color=color, ls=ls, lw=1.2)
ax2.set_ylabel("BESS dispatch (kW)")
ax2.set_xlabel("Time (s)")
ax2.grid(alpha=0.3)
fig.suptitle("Joint supervisory-AI / interface evaluation: 2 s full MV interruption", fontsize=8.5)
fig.tight_layout()
fig.savefig("fig_dqn_joint.png")
plt.close(fig)


# ---------------------------------------------------------------------
# Fig. J: DYNAMIC electro-thermal transient during an actual ride-through
# window (Section 6.3 extension) -- contrasts with Fig. G's CONSTANT-loss
# step response: this couples the Foster network to the actual time-
# varying device loss during the SST's own full-interruption scenarios,
# showing the MV link voltage (top) and each device's dTj deviation from
# its own pre-event steady state (bottom), for the paper's fixed 60 kW
# test-step scenario (500 ms, left) and the design's own rated-power
# T_HOLD-budget scenario (right).
# ---------------------------------------------------------------------
tt = np.load("sst_thermal_transient_logs.npz")
fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.2), sharex="col")
for col, prefix, title, sag_start, sag_dur in [
        (0, "s500", "60 kW test step, 500 ms interruption", 0.5, 0.500),
        (1, "srated", "Rated-power (150 kW) step, T_HOLD interruption", 0.5, None)]:
    t = tt[f"{prefix}_t"]
    ax_top, ax_bot = axes[0, col], axes[1, col]
    ax_top.plot(t, tt[f"{prefix}_V1"], color="tab:purple", lw=1.2)
    ax_top.axhspan(3300 * 0.85, 3300 * 1.15, color="gray", alpha=0.08)
    ax_top.set_ylabel("Per-cell $V_1$ (V)" if col == 0 else "")
    ax_top.set_title(title, fontsize=8)
    ax_top.grid(alpha=0.3)
    ax_bot.plot(t, tt[f"{prefix}_dtj_chb"], label="CHB cell IGBT", lw=1.2)
    ax_bot.plot(t, tt[f"{prefix}_dtj_dab_igbt"], label="DAB primary IGBT", lw=1.2)
    ax_bot.plot(t, tt[f"{prefix}_dtj_dab_sic"], label="DAB secondary SiC", lw=1.2, ls="--")
    ax_bot.axhline(0, color="k", lw=0.6, alpha=0.5)
    ax_bot.set_xlabel("Time (s)")
    ax_bot.set_ylabel(r"$\Delta T_j$ vs. pre-event (degC)" if col == 0 else "")
    ax_bot.grid(alpha=0.3)
    if col == 0:
        ax_bot.legend(fontsize=6.5, loc="lower left")
fig.suptitle("Dynamic electro-thermal transient during MV-side ride-through", fontsize=9)
fig.tight_layout()
fig.savefig("fig_thermal_transient.png")
plt.close(fig)

print("Saved fig_dab_waveform.png, fig_dab_power.png, fig_chb_waveform.png, "
      "fig_sag_ridethrough.png, fig_coincident_ridethrough.png, "
      "fig_montecarlo.png, fig_thermal_step.png, fig_balancing.png, fig_dqn_joint.png, "
      "fig_thermal_transient.png")
