import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D

fig = plt.figure(figsize=(13.28, 5.31), dpi=100)  # 1328x531 px at 100dpi
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 100); ax.set_ylim(0, 40)
ax.axis("off")

def box(x, y, w, h, text, fc="#eef2f7", ec="#1F3A5F", fontsize=9.5, weight="normal"):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2",
                        linewidth=1.4, edgecolor=ec, facecolor=fc)
    ax.add_patch(b)
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=fontsize,
             color="#1F3A5F", weight=weight, linespacing=1.3)

# Title
ax.text(50, 38, "AI-Assisted Supervisory Energy Management for a PV-BESS Microgrid\nvia a Solid-State Transformer Grid Interface",
        ha="center", va="center", fontsize=12.5, weight="bold", color="#1F3A5F")

# Conventional path (top)
box(2, 27, 20, 6, "PV + BESS\n(100 kWp / 200 kWh)", fc="#f7f9fc")
box(26, 27, 20, 6, "LFT + 2-level VSC\n(conventional)", fc="#fbe9e7")
box(50, 27, 20, 6, "MV grid sag\n→ trips in ms", fc="#fbe9e7")
ax.annotate("", xy=(26, 30), xytext=(22, 30), arrowprops=dict(arrowstyle="->", color="#1F3A5F", lw=1.6))
ax.annotate("", xy=(50, 30), xytext=(46, 30), arrowprops=dict(arrowstyle="->", color="#1F3A5F", lw=1.6))

# Proposed path (bottom)
box(2, 18, 20, 6, "PV + BESS\n(100 kWp / 200 kWh)", fc="#f7f9fc")
box(26, 18, 20, 6, "CHB + DAB + VSC\n(proposed SST)", fc="#e3f2e1")
box(50, 18, 20, 6, "MV grid sag\n→ rides through", fc="#e3f2e1")
ax.annotate("", xy=(26, 21), xytext=(22, 21), arrowprops=dict(arrowstyle="->", color="#1F3A5F", lw=1.6))
ax.annotate("", xy=(50, 21), xytext=(46, 21), arrowprops=dict(arrowstyle="->", color="#1F3A5F", lw=1.6))

# vs divider
ax.text(1, 23, "vs.", ha="left", va="center", fontsize=10, style="italic", color="#888")

# Stat callouts (right column)
stats = [
    ("94.3%", "full-SST efficiency\n(electro-thermal sim.)"),
    ("1.2% vs 57.8%", "Monte Carlo trip rate,\nSST vs. conventional"),
    ("~1 s", "active-balancing\nconvergence time"),
]
for i, (num, lab) in enumerate(stats):
    x0 = 74
    y0 = 27 - i * 8.2
    box(x0, y0, 24, 7, "", fc="#1F3A5F", ec="#1F3A5F")
    ax.text(x0 + 12, y0 + 4.6, num, ha="center", va="center", fontsize=13, weight="bold", color="white")
    ax.text(x0 + 12, y0 + 1.9, lab, ha="center", va="center", fontsize=8, color="#dfe6f0", linespacing=1.2)

ax.text(50, 3, "Same power class, isolating the grid-interface architecture as the only variable",
        ha="center", va="center", fontsize=9, style="italic", color="#555")

fig.savefig("fig_graphical_abstract.png", dpi=100)
print("saved fig_graphical_abstract.png")
