"""
SST paper -- frozen vs. SST-aware-retrained DQN comparison (Section 6.6
extension, reviewer item 1's "Actionable Roadmap" step 1: "add comparative
performance table").

Runs BOTH the original frozen checkpoint (sst_dqn_reused.pt, trained only
against sapec_sim.py's plant -- see that module's docstring) and the newly
retrained SST-aware checkpoint (sst_dqn_sst_aware.pt, produced by
sst_dqn_train_sst_aware.py, trained with the SST's own fine-resolution
mv_link_step() physics injected into the grid_disturbance segment) through
the EXACT SAME joint evaluation already used for Section 6.6
(sst_dqn_joint.evaluate_joint(), the shared 2 s full MV interruption
scenario) against BOTH interfaces -- four policy x interface combinations
in total. Only the CHECKPOINT differs between the "frozen" and "retrained"
rows; the evaluation scenario, interface physics, and metrics code are
identical, isolating training-plant as the only variable being compared.

Metrics reported, beyond what sst_dqn_joint.py already computes
(vdc_max_dev_pct, tripped, SOC at/around the event):
  - BESS throughput during the logged event window (kWh, integral of
    |p_bess| dt) and the equivalent-full-cycle (EFC) turnover this
    represents (same USABLE_KWH/EFC convention as sst_economics.py,
    Section 6.7) -- a genuine battery-stress-cycle proxy: more throughput
    for the same disturbance means more cycling stress on the same
    hardware, not a separately assumed SOH model.
  - Peak command slew (kW/s) during the window -- a smoothness/stress
    proxy already used elsewhere in this paper (sapec_sim.evaluate()'s
    command_smoothness_kW_per_s), computed here over just the event
    window rather than the full scenario.
"""
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(__file__))
from sapec_sim import QNet, normalize_state, ACTIONS, PIBaseline, DT_DEC  # noqa: E402
from sst_dqn_joint import evaluate_joint, SAG_START_LOCAL, SAG_DUR  # noqa: E402

USABLE_KWH = 140.0  # matches sst_economics.py: 200 kWh nameplate, 20-90% SOC window


def load_qnet(pt_name):
    qnet = QNet()
    qnet.load_state_dict(torch.load(
        os.path.join(os.path.dirname(__file__), pt_name), map_location="cpu"))
    qnet.eval()

    def policy(pv, load, soc, vdc_proxy, dt, pbess_prev=0.0):
        s_vec = normalize_state(pv, load, soc, vdc_proxy, pbess_prev)
        with torch.no_grad():
            q = qnet(torch.tensor(s_vec).unsqueeze(0))
            a_idx = int(torch.argmax(q, dim=1).item())
        return float(ACTIONS[a_idx])
    return policy


def event_window_stress(log):
    """BESS throughput (kWh) and peak command slew (kW/s) over the logged
    fine-resolution window bracketing the shared sag (already restricted
    to [SAG_START_LOCAL-2, SAG_START_LOCAL+SAG_DUR+3] by evaluate_joint's
    own log_lo/log_hi)."""
    t, p = log["t"], log["pbess"]
    if len(t) < 2:
        return dict(bess_throughput_kwh=None, efc_turnover=None, peak_slew_kw_per_s=None)
    dt = np.diff(t)
    throughput_kwh = float(np.sum(np.abs(p[:-1]) * dt) / 3600.0)
    efc = throughput_kwh / USABLE_KWH
    slew = np.diff(p) / dt
    peak_slew = float(np.max(np.abs(slew))) if len(slew) else 0.0
    return dict(bess_throughput_kwh=round(throughput_kwh, 4),
                efc_turnover=round(efc, 6),
                peak_slew_kw_per_s=round(peak_slew, 2))


if __name__ == "__main__":
    policies = {
        "frozen_dqn": load_qnet("sst_dqn_reused.pt"),
        "sst_aware_dqn": load_qnet("sst_dqn_sst_aware.pt"),
    }

    results = {}
    for pname, pfn in policies.items():
        for iface in ["conventional", "sst"]:
            rng = np.random.default_rng(99)
            metrics, log = evaluate_joint(iface, pfn, rng, f"{pname}, {iface} interface")
            stress = event_window_stress(log)
            key = f"{iface}_{pname}"
            results[key] = {**metrics, **stress}
            print(f"{key:28s}  Vdc max dev={metrics['vdc_max_dev_pct']:.4f}%  "
                  f"tripped={metrics['tripped']}  "
                  f"throughput={stress['bess_throughput_kwh']} kWh  "
                  f"EFC={stress['efc_turnover']}  "
                  f"peak slew={stress['peak_slew_kw_per_s']} kW/s")

    # Head-to-head deltas per interface: retrained vs frozen, same physics
    comparison = {}
    for iface in ["conventional", "sst"]:
        f = results[f"{iface}_frozen_dqn"]
        a = results[f"{iface}_sst_aware_dqn"]
        comparison[iface] = dict(
            vdc_max_dev_pct_frozen=f["vdc_max_dev_pct"],
            vdc_max_dev_pct_sst_aware=a["vdc_max_dev_pct"],
            tripped_frozen=f["tripped"],
            tripped_sst_aware=a["tripped"],
            bess_throughput_kwh_frozen=f["bess_throughput_kwh"],
            bess_throughput_kwh_sst_aware=a["bess_throughput_kwh"],
            throughput_reduction_pct=round(
                100.0 * (f["bess_throughput_kwh"] - a["bess_throughput_kwh"]) / f["bess_throughput_kwh"], 2
            ) if f["bess_throughput_kwh"] else None,
            peak_slew_frozen=f["peak_slew_kw_per_s"],
            peak_slew_sst_aware=a["peak_slew_kw_per_s"],
            soc_min_frozen=f["soc_min_in_window"],
            soc_min_sst_aware=a["soc_min_in_window"],
        )
        print(f"\n=== {iface} interface: frozen vs. SST-aware-retrained ===")
        print(json.dumps(comparison[iface], indent=2))

    with open("sst_dqn_compare_results.json", "w") as fjson:
        json.dump(dict(per_combo=results, comparison=comparison), fjson, indent=2)
    print("\nSaved sst_dqn_compare_results.json")
