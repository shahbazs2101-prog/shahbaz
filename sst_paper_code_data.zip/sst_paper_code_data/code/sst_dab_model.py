"""
SST paper -- dual active bridge (DAB) isolation-stage design + switching-
resolution verification.

Architecture context (see sst_chb_model.py and sst_sim.py for the other two
stages): the proposed solid-state transformer (SST) replaces the plain
11 kV/415 V line-frequency transformer (LFT) + grid-tie VSC interface used
in the author's prior digest [ref: converter/VSC paper] with a three-stage
AC-DC-DC-AC SST, at the SAME power class and load (150 kVA, 100 kWp PV,
200 kWh/100 kW BESS, 60-120 kW local load) so the interface can be swapped
in isolation:

  Stage 1 (MV AC -> MV DC): N=3 series cascaded H-bridge (CHB) cells per
    phase (9 cells total), each cell DC-link V1 = 3300 V -- a common MV
    SiC/IGBT device class -- giving max combined phase-voltage amplitude
    N*V1 = 9900 V against the 8981.5 V peak phase voltage required for
    11 kV service, modulation index ma = 0.907 (sst_chb_model.py).

  Stage 2 (MV DC -> LV DC, isolated): THIS FILE. Each of the 9 CHB cells
    feeds its own dedicated dual active bridge (DAB) DC-DC converter through
    a medium-frequency transformer (MFT), with all 9 DAB secondaries
    paralleled onto a COMMON 800 V LV DC bus -- deliberately the same 800 V
    used in the author's prior digest, so the existing BESS buck-boost
    converter and PV boost-stage designs [ref] attach unchanged.

  Stage 3 (LV DC -> LV AC): a grid-tie inverter feeding the local 415 V
    AC load/microgrid bus -- same switching-VSC topology and control as the
    author's prior digest's grid-tie VSC [ref], now sourced from the SST's
    internal 800 V bus instead of directly from the BESS/PV, so its own
    switching-resolution model is not re-derived here (it is unchanged
    hardware, already verified).

This script designs and switching-verifies ONE representative DAB cell
(all 9 are identical by the balanced/modular design above, so one
verified cell stands for all nine -- explicitly disclosed, not hidden).
"""
import numpy as np
import json

# ---------------------------------------------------------------------
# 1. Per-cell design targets
# ---------------------------------------------------------------------
S_TOTAL = 150e3          # VA, total SST rating (matches prior digest's VSC)
N_CELLS = 3               # series CHB cells per phase (sst_chb_model.py)
N_PHASES = 3
P_CELL = S_TOTAL / N_PHASES / N_CELLS   # W, real power per cell at rated load

V1_NOM = 3300.0            # V, per-cell MV-side DC link (CHB cell output)
V2_NOM = 800.0             # V, common LV DC bus (matches prior digest's Vdc)
N_TURNS = 4.0              # MFT turns ratio (primary:secondary), rounded from
                            # V1/V2 = 4.125 for a clean winding ratio -- the
                            # resulting ~3% primary/secondary voltage mismatch
                            # is absorbed by phase-shift control margin, a
                            # standard, disclosed DAB design simplification.
FS = 10e3                  # Hz, MFT/DAB switching frequency (matches the
                            # buck-boost converter's 10 kHz in the prior
                            # digest for pipeline consistency)
D_RATED = 0.35              # duty (phase-shift/pi) at rated power, leaving
                            # margin to the d=0.5 max-power-transfer point
                            # for transient/regulation headroom


def dab_power(d, V1=V1_NOM, V2=V2_NOM, n=N_TURNS, Lk=None, fs=FS):
    """Single-phase-shift DAB power transfer, referred to the primary:
    P = n*V1*V2*d*(1-d) / (2*fs*Lk), 0<=d<=0.5 (d=phase-shift/pi)."""
    return n * V1 * V2 * d * (1 - d) / (2 * fs * Lk)


def size_Lk(P_target, d=D_RATED, V1=V1_NOM, V2=V2_NOM, n=N_TURNS, fs=FS):
    return n * V1 * V2 * d * (1 - d) / (2 * fs * P_target)


LK = size_Lk(P_CELL)   # H, referred-to-primary leakage inductance


# ---------------------------------------------------------------------
# 2. ZVS boundary (standard single-phase-shift DAB result): primary-side
#    ZVS requires the transformer current to already be flowing in the
#    correct direction at each bridge's switching instant. For V1 ~ n*V2
#    (the "voltage-matched" case, true here since 3300 V is within ~3% of
#    n*V2=3200 V), ZVS holds for the whole practical 0<d<0.5 range on both
#    bridges; this is verified numerically below rather than assumed.
# ---------------------------------------------------------------------
def zvs_margin(d, V1=V1_NOM, V2=V2_NOM, n=N_TURNS, Lk=LK, fs=FS):
    """Returns (i_zero_primary, i_zero_secondary): the transformer current
    (referred to primary) at the two bridges' own switching instants -- the
    primary switches at t=0 (and t=T/2), the secondary at t=d*T/2 (and
    t=T/2+d*T/2). ZVS on a bridge requires ITS OWN switching-instant current
    to have the correct sign to displace that bridge's device capacitance:
    primary needs i(0)<0 (current still flowing from the previous half-cycle
    as the primary bridge switches), secondary needs i(d*T/2)>0. Evaluated
    numerically from the same piecewise-linear model simulate_dab() uses,
    not a separately-trusted closed form -- both must agree."""
    T = 1.0 / fs
    V2r = n * V2   # secondary voltage referred to primary
    t_shift = d * T / 2.0
    slope_a = (V1 + V2r) / Lk    # interval [0, t_shift): v1=+V1, v2'=-V2r
    slope_b = (V1 - V2r) / Lk    # interval [t_shift, T/2): v1=+V1, v2'=+V2r
    # periodic steady state: i(T/2) = -i(0) (half-wave symmetry), and
    # i(T/2) = i(0) + slope_a*t_shift + slope_b*(T/2 - t_shift)
    # => -i(0) = i(0) + slope_a*t_shift + slope_b*(T/2 - t_shift)
    i0 = -(slope_a * t_shift + slope_b * (T / 2 - t_shift)) / 2.0
    i_shift = i0 + slope_a * t_shift   # current at t = d*T/2 (secondary's switching instant)
    return i0, i_shift


# ---------------------------------------------------------------------
# 3. Switched (piecewise-constant-di/dt) time-domain verification, in the
#    same spirit as converter_model.py's Test A: apply the actual SPS
#    square-wave bridge voltages, integrate the leakage-inductor current,
#    measure the resulting average delivered power over one full switching
#    period at steady state, and compare with the analytic formula above.
# ---------------------------------------------------------------------
def simulate_dab(d, V1=V1_NOM, V2=V2_NOM, n=N_TURNS, Lk=LK, fs=FS,
                  n_periods=60, steps_per_period=4000):
    T = 1.0 / fs
    dt = T / steps_per_period
    V2r = n * V2
    i = 0.0
    log_start = (n_periods - 5) * steps_per_period
    i_log, v1_log, v2_log, t_log = [], [], [], []
    for k in range(n_periods * steps_per_period):
        t = k * dt
        phase = (t % T) / T
        # primary bridge: +V1 for phase in [0,0.5), -V1 for [0.5,1)
        v1_sw = V1 if phase < 0.5 else -V1
        # secondary bridge: same square wave, delayed by d*T/2 -- the
        # standard SPS mapping between phase-shift ANGLE phi in [0,pi]
        # (d = phi/pi in [0,1]) and TIME delay phi/(2*pi)*T = d*T/2, referred
        # to primary as V2r
        phase2 = (phase - d / 2.0) % 1.0
        v2_sw = V2r if phase2 < 0.5 else -V2r
        di = (v1_sw - v2_sw) / Lk
        i += di * dt
        if k >= log_start:
            i_log.append(i); v1_log.append(v1_sw); v2_log.append(v2_sw); t_log.append(t)
    i_log = np.array(i_log); v1_log = np.array(v1_log)
    t_log = np.array(t_log)
    # average real power delivered = average(v1(t) * i(t)) over an integer
    # number of periods (last full period of the logged tail)
    one_period = steps_per_period
    p_avg = float(np.mean(v1_log[-one_period:] * i_log[-one_period:]))
    i_pkpk = float(i_log[-one_period:].max() - i_log[-one_period:].min())
    return p_avg, i_pkpk, i_log, v1_log, np.array(v2_log), t_log


if __name__ == "__main__":
    print(f"Per-cell rated power: {P_CELL/1e3:.3f} kW  (150 kVA / {N_PHASES} phases / {N_CELLS} cells)")
    print(f"MFT turns ratio n = {N_TURNS} (V1/V2 nominal = {V1_NOM/V2_NOM:.3f}, "
          f"n*V2 = {N_TURNS*V2_NOM:.0f} V vs V1 = {V1_NOM:.0f} V, "
          f"{100*abs(N_TURNS*V2_NOM-V1_NOM)/V1_NOM:.2f}% mismatch)")
    print(f"Sized leakage inductance Lk (primary-referred) = {LK*1e6:.2f} uH "
          f"for rated power at d={D_RATED}")

    print(f"\n{'d':<8}{'analytic P (kW)':<18}{'simulated P (kW)':<18}{'error':<8}{'i_pkpk (A)':<12}")
    results = {}
    for d in [0.10, 0.20, 0.35, 0.45, 0.50]:
        analytic = dab_power(d, Lk=LK) / 1e3
        p_sim, i_pkpk, i_log, v1_log, v2_log, t_log = simulate_dab(d, Lk=LK)
        p_sim_kw = p_sim / 1e3
        err = abs(p_sim_kw - analytic) / analytic * 100 if analytic > 0 else 0.0
        print(f"{d:<8.2f}{analytic:<18.4f}{p_sim_kw:<18.4f}{err:<8.3f}%{i_pkpk:<12.2f}")
        results[d] = dict(analytic_kW=round(analytic, 4), simulated_kW=round(p_sim_kw, 4),
                           error_pct=round(err, 4), i_pkpk_A=round(i_pkpk, 2))

    # ZVS check at rated d
    i0, i_d = zvs_margin(D_RATED)
    print(f"\nZVS check at rated d={D_RATED}: i(0)={i0:.2f} A (need <0 for primary ZVS), "
          f"i(dT/2)={i_d:.2f} A (need >0 for secondary ZVS) "
          f"-> {'ZVS on both bridges' if (i0 < 0 and i_d > 0) else 'HARD-SWITCHED region'}")

    # sweep ZVS boundary across the operating duty range
    zvs_sweep = {}
    for d in np.linspace(0.02, 0.5, 25):
        i0, i_d = zvs_margin(d)
        zvs_sweep[round(float(d), 3)] = bool(i0 < 0 and i_d > 0)
    d_zvs_min = min(d for d, ok in zvs_sweep.items() if ok)
    all_zvs_above_min = all(ok for d, ok in zvs_sweep.items() if d >= d_zvs_min)
    print(f"ZVS holds for d >= {d_zvs_min:.3f} (rated operating point d={D_RATED} is "
          f"{'inside' if D_RATED >= d_zvs_min else 'OUTSIDE'} the ZVS region)")

    # waveform capture at rated operating point, for the paper's figure
    p_sim, i_pkpk, i_log, v1_log, v2_log, t_log = simulate_dab(D_RATED, Lk=LK, n_periods=64,
                                                                 steps_per_period=4000)

    out = dict(
        P_cell_kW=round(P_CELL / 1e3, 4), N_cells=N_CELLS, N_phases=N_PHASES,
        V1_nom_V=V1_NOM, V2_nom_V=V2_NOM, turns_ratio=N_TURNS,
        turns_ratio_mismatch_pct=round(100 * abs(N_TURNS * V2_NOM - V1_NOM) / V1_NOM, 3),
        fs_Hz=FS, Lk_uH=round(LK * 1e6, 3), d_rated=D_RATED,
        sweep=results, zvs_d_min=round(d_zvs_min, 4),
        zvs_holds_at_rated=bool(D_RATED >= d_zvs_min),
        rated_i_pkpk_A=round(i_pkpk, 2),
    )
    with open("sst_dab_results.json", "w") as f:
        json.dump(out, f, indent=2)
    np.savez("sst_dab_waveform.npz", t=t_log, i=i_log, v1=v1_log, v2=v2_log)
    print("\nSaved sst_dab_results.json and sst_dab_waveform.npz")
