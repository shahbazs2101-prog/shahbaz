"""
SST paper -- joint supervisory-AI/interface evaluation (Section VI-F): runs
the trained DQN supervisory EMS (the same checkpoint reused from the prior
digest, sst_dqn_reused.pt -- NOT retrained here, since the interface swap
does not change the plant the DQN was trained against under nominal
operation, Section VI-A) TOGETHER with the SST's own fine-resolution
interface physics (mv_link_step(), sst_sim.py) during a shared MV sag
window, instead of evaluating the two questions ("does the supervisory
policy dispatch well?" and "does the interface ride through a sag?")
separately as the rest of this paper does.

Why this is a genuinely new evaluation, not a re-run of existing pieces:
sapec_sim.py's own evaluate() function already runs the DQN at fine
resolution during its "grid_disturbance" segment, but that segment models
a 50 s SUPERVISORY-level islanding event (the microgrid disconnects from
the grid entirely and must self-supply from PV+BESS) with NO interface-
level buffering physics at all -- grid_flow is simply zeroed while
islanded. It does not exercise the SST's own sub-second MV-link ride-
through mechanism (mv_link_step()) at all, because that mechanism was
built later, for this paper, and only ever driven by a FIXED disturbance
step (sst_sim.py's evaluate_sag()), never by the DQN's own actual BESS
dispatch. This script closes that gap: at each 1 s supervisory decision
interval, the DQN (or the PI baseline, for comparison) observes
(pv, load, soc, vdc_proxy, pbess_prev) exactly as trained and issues a
BESS dispatch command; that command then determines the net LV-bus power
balance, which is fed through the ACTUAL interface physics (either the
conventional single-link model or the SST's MV-link energy-balance model)
at fine (0.2 ms) resolution for a short MV voltage sag embedded in the
window, and the resulting vdc_proxy is what the DQN observes at the NEXT
decision step -- a genuine closed loop between the two layers, not two
independently-evaluated pieces.

Disclosed scope note: the DQN was trained (sapec_sim.py) against the
conventional interface's own bus dynamics (average-model, always-available
grid). It is evaluated here, UNMODIFIED, against BOTH interfaces during a
sag it never saw in training -- so this is also, honestly, a mild
out-of-distribution stress test of the frozen policy, not a claim that the
DQN was trained SST-aware.
"""
import numpy as np
import json
import sys
import os
import torch

sys.path.insert(0, os.path.dirname(__file__))
from sapec_sim import (QNet, PIBaseline, normalize_state, ACTIONS, N_ACTIONS,  # noqa: E402
                        VDC_NOM, C_BUS_EQ, KP_V, KI_V, BESS_P, SLEW_MAX,
                        TRACK_ERR, DT_DEC, DT_FINE, profile, clamp_to_limits)
from sst_sim import V1_NOM, P_CELL, C_MV, V1_FLOOR, mv_link_step  # noqa: E402

SEG = "grid_disturbance"     # reuse the prior digest's own PV/load profile
                              # for this segment (Section II), NOT its 50 s
                              # islanding window -- see module docstring
SEG_LEN = 600.0
SAG_START_LOCAL = 250.0      # s into the segment (matches the ORIGINAL
                              # islanding window's own start time, for
                              # continuity with the prior digest's scenario
                              # naming, even though the duration below is
                              # now sub-second/interface-relevant instead
                              # of the original 50 s supervisory islanding)
SAG_DEPTH = 1.00              # full MV interruption (worst case already
                              # characterized in Section VI-B/Table II)
SAG_DUR = 2.0                 # s -- deliberately spans TWO 1 s supervisory
                              # decision steps, so the DQN gets a chance to
                              # observe and react mid-event, unlike the
                              # sub-1s scenarios in Table II


def load_dqn():
    qnet = QNet()
    qnet.load_state_dict(torch.load(
        os.path.join(os.path.dirname(__file__), "sst_dqn_reused.pt"),
        map_location="cpu"))
    qnet.eval()

    def dqn_policy(pv, load, soc, vdc_proxy, dt, pbess_prev=0.0):
        s_vec = normalize_state(pv, load, soc, vdc_proxy, pbess_prev)
        with torch.no_grad():
            q = qnet(torch.tensor(s_vec).unsqueeze(0))
            a_idx = int(torch.argmax(q, dim=1).item())
        return float(ACTIONS[a_idx])
    return dqn_policy


def grid_avail_fraction_local(tl):
    if SAG_START_LOCAL <= tl < SAG_START_LOCAL + SAG_DUR:
        return 1.0 - SAG_DEPTH
    return 1.0


def evaluate_joint(interface, policy_fn, rng, label):
    """interface: 'conventional' or 'sst'. policy_fn(pv, load, soc,
    vdc_proxy, dt, pbess_prev) -> p_raw dispatch command, kW."""
    soc = 60.0
    vdc = VDC_NOM
    V1 = V1_NOM * 9        # aggregate 9-cell MV link, same lumping as
                            # sst_sim.py's evaluate_sag()
    z_integ = 0.0
    pbess_prev = 0.0
    n_fine_per_dec = int(DT_DEC / DT_FINE)
    n_steps = int(SEG_LEN / DT_DEC)

    log = {k: [] for k in ["t", "pv", "load", "soc", "vdc", "V1", "pbess", "grid_frac"]}
    tripped_at = None

    # window of interest for fine-resolution logging (keep the log small --
    # full-segment fine logging at 0.2ms for 600s would be enormous)
    log_lo, log_hi = SAG_START_LOCAL - 2.0, SAG_START_LOCAL + SAG_DUR + 3.0

    for k in range(n_steps):
        tl = k * DT_DEC
        pv, load, _ = profile(SEG, tl, rng)
        vdc_proxy = vdc   # the policy observes the ACTUAL bus voltage from
                           # the joint physics below, not a separate static
                           # proxy -- a stricter, more honest information
                           # channel than sapec_sim.py's own coarse-mode
                           # linearized proxy
        p_raw = policy_fn(pv, load, soc, vdc_proxy, DT_DEC, pbess_prev)
        p_clamped = clamp_to_limits(p_raw, soc, DT_DEC)

        do_fine = log_lo - 5.0 <= tl <= log_hi + 5.0   # only need fine
                                                         # dynamics near the
                                                         # disturbance; bus
                                                         # is quiescent
                                                         # elsewhere at this
                                                         # supervisory power
                                                         # class (same
                                                         # argument as
                                                         # sapec_sim.py's
                                                         # FINE_SEGMENTS)
        if do_fine:
            p_now = pbess_prev
            for kf in range(n_fine_per_dec):
                tf = tl + kf * DT_FINE
                gf = grid_avail_fraction_local(tf)
                max_step = SLEW_MAX * DT_FINE
                p_now += max(-max_step, min(max_step, p_clamped - p_now))
                p_eff = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
                p_in_w = (pv + p_eff - load) * 1000.0

                if tripped_at is not None:
                    pass
                elif interface == "conventional":
                    p_rated_w = P_CELL * 9
                    p_avail_w = p_rated_w * gf
                    e = vdc - VDC_NOM
                    p_cmd_w = KP_V * e + KI_V * z_integ
                    p_out_w = float(np.clip(p_cmd_w, -p_avail_w, p_avail_w))
                    dV = (p_in_w - p_out_w) / (C_BUS_EQ * vdc) * DT_FINE
                    vdc += dV
                    z_integ += e * DT_FINE
                else:  # sst
                    p_grid_avail_w = (P_CELL * 9) * gf
                    e = vdc - VDC_NOM
                    p_cmd_w = KP_V * e + KI_V * z_integ
                    V1, p_out_w = mv_link_step(V1, p_grid_avail_w, p_cmd_w, DT_FINE, c=C_MV * 9)
                    dV = (p_in_w - p_out_w) / (C_BUS_EQ * vdc) * DT_FINE
                    vdc += dV
                    z_integ += e * DT_FINE

                if tripped_at is None and abs(vdc - VDC_NOM) / VDC_NOM > 0.20:
                    tripped_at = tf
                    vdc = VDC_NOM * (1 + 0.20 * np.sign(vdc - VDC_NOM))

                if log_lo <= tf <= log_hi:
                    log["t"].append(tf); log["pv"].append(pv); log["load"].append(load)
                    log["soc"].append(soc); log["vdc"].append(vdc)
                    log["V1"].append(V1 / 9); log["pbess"].append(p_now)
                    log["grid_frac"].append(gf)
            p_delivered = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
        else:
            max_step = SLEW_MAX * DT_DEC
            p_now = pbess_prev + max(-max_step, min(max_step, p_clamped - pbess_prev))
            p_delivered = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
            if not (log_lo <= tl <= log_hi):
                pass

        soc = float(np.clip(soc - p_delivered * DT_DEC / 3600.0 / 200.0 * 100.0, 0, 100))
        pbess_prev = p_delivered

    for kk in log:
        log[kk] = np.array(log[kk])
    vdc_dev = log["vdc"] - VDC_NOM if len(log["vdc"]) else np.array([0.0])
    return dict(
        label=label, interface=interface,
        vdc_max_dev_pct=round(float(np.max(np.abs(vdc_dev))) / VDC_NOM * 100, 4),
        tripped=tripped_at is not None,
        time_to_trip_s=round(tripped_at - SAG_START_LOCAL, 4) if tripped_at is not None else None,
        soc_at_sag_start=round(float(np.interp(SAG_START_LOCAL, [t for t in log["t"]], log["soc"])), 3) if len(log["t"]) else None,
        soc_min_in_window=round(float(np.min(log["soc"])), 3) if len(log["soc"]) else None,
        pbess_range_kW=[round(float(np.min(log["pbess"])), 2), round(float(np.max(log["pbess"])), 2)] if len(log["pbess"]) else None,
    ), log


if __name__ == "__main__":
    dqn_policy_raw = load_dqn()
    pi = PIBaseline()

    def dqn_policy(pv, load, soc, vdc_proxy, dt, pbess_prev=0.0):
        return dqn_policy_raw(pv, load, soc, vdc_proxy, dt, pbess_prev)

    def pi_policy(pv, load, soc, vdc_proxy, dt, pbess_prev=0.0):
        return pi.act(pv, load, soc, vdc_proxy, dt)

    combos = [
        ("conventional", pi_policy, "PI baseline, conventional interface"),
        ("conventional", dqn_policy, "DQN, conventional interface"),
        ("sst", pi_policy, "PI baseline, SST interface"),
        ("sst", dqn_policy, "DQN, SST interface"),
    ]

    all_results = {}
    logs = {}
    for iface, pol, label in combos:
        pi_local = PIBaseline()  # fresh integrator state per PI run
        if pol is pi_policy:
            def pol_bound(pv, load, soc, vdc_proxy, dt, pbess_prev=0.0, _pi=pi_local):
                return _pi.act(pv, load, soc, vdc_proxy, dt)
            use_pol = pol_bound
        else:
            use_pol = pol
        rng = np.random.default_rng(99)
        metrics, log = evaluate_joint(iface, use_pol, rng, label)
        key = f"{iface}_{'dqn' if pol is dqn_policy else 'pi'}"
        all_results[key] = metrics
        logs[key] = log
        print(f"{label:36s}  Vdc max dev={metrics['vdc_max_dev_pct']:.4f}%  "
              f"tripped={metrics['tripped']}  "
              f"SOC at sag start={metrics['soc_at_sag_start']}  "
              f"pbess range={metrics['pbess_range_kW']} kW")

    with open("sst_dqn_joint_results.json", "w") as f:
        json.dump(all_results, f, indent=2)
    np.savez("sst_dqn_joint_logs.npz", **{
        f"{k}_{field}": v for k, log in logs.items() for field, v in log.items()
    })
    print("\nSaved sst_dqn_joint_results.json and sst_dqn_joint_logs.npz")
