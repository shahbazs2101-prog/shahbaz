"""
SST paper -- switching-loss-based efficiency simulation for the CHB and DAB
stages, replacing the literature-typical per-stage efficiency ASSUMPTION
used earlier in the paper with a genuine, simulation-based loss estimate
for the two NEW stages this paper introduces. The reused LV grid-tie
inverter (Section IV-C) is unchanged hardware from [1] and keeps its own
prior literature-typical figure, since it is out of scope for
re-verification here (same "unchanged hardware, not re-verified" boundary
used throughout this paper).

This script does NOT introduce a new circuit model: it re-uses the exact
switching sequences already produced and verified in sst_chb_model.py
(PSC-PWM) and sst_dab_model.py (SPS square waves), and layers a device
loss accounting on top of the same current waveforms already validated
there against the analytic power-transfer formulas. Conduction loss is
integrated numerically over the actual simulated current, and switching
loss is charged at every ACTUAL switching transition detected in the
simulated PWM/SPS sequence (not assumed from the nominal carrier
frequency) -- so a wrong device or duty-cycle assumption would show up as
a wrong number of detected events, not just a wrong scale factor.

REVISION (electro-thermal extension): the first version of this script
used a constant, temperature-independent conduction drop / switching
energy, sourced from a short-form manufacturer catalog entry (Farnell's
2-page summary of the Infineon FF400R33KF2C). Pulling the FULL datasheet
(Infineon FF400R33KF2C_DS_v02_01, via Mouser) for this revision surfaced
two corrections and one genuine extension:

  1. CORRECTION: the short-form catalog's "Vce,sat = 3.4 V" figure is
     actually the datasheet's MINIMUM spec at Tvj=25 degC, not the typical
     value used throughout this paper's earlier efficiency numbers. The
     full datasheet's typical value is 4.25 V at 25 degC and 4.30 V at
     125 degC (IC=400A, VGE=15V) -- i.e. this device's Vce,sat is both
     higher than previously assumed AND essentially temperature-flat
     (+0.05 V over 100 degC), a real, disclosed device characteristic, not
     an assumption.
  2. CORRECTION: the short-form catalog's Eon/Eoff = 960/510 mWs figure
     was listed as IDENTICAL at Tvj=25 and 125 degC, which is not
     physically typical (tail-current-driven turn-off loss normally rises
     with junction temperature) and turns out to be a catalog rounding
     artifact. The full datasheet gives distinct, temperature-varying
     values -- Eon = 470/730 mJ and Eoff = 430/510 mJ at Tvj=25/125 degC --
     at test conditions VCE=1800V, IC=400A, RGon=2.7 ohm, RGoff=3.6 ohm,
     CGE=68nF, LS=60nH. This CONFIRMS (rather than merely assumes, as
     before) the VCE=1800V/IC=400A test point used throughout this
     script's switching-energy scaling.
  3. EXTENSION: the full datasheet also publishes a 4-branch Foster
     thermal network (ri, taui) for both the IGBT and diode junction-to-
     case impedance, letting this script replace the earlier "no thermal
     feedback, single fixed 25 degC parameter set" model with (a) a
     temperature-dependent conduction/switching parameter set, evaluated
     at each device's own self-consistent steady-state junction
     temperature via iterative electro-thermal convergence against a
     disclosed case temperature, and (b) an explicit transient thermal
     step-response computed directly from the manufacturer's own Foster
     RC network (not a single lumped Rth(j-c) number), showing how long
     each device's junction temperature actually takes to settle.

  The Wolfspeed WAS350M12BM3 SiC datasheet publishes only GRAPHICAL
  Zth(j-c) transient curves, not tabulated Foster RC coefficients -- so the
  SiC secondary bridge gets a single steady-state Rth(j-c) = 0.116 degC/W
  (from the same datasheet) rather than a full 4-branch transient network.
  This asymmetry (full transient network for the IGBT, steady-state-only
  for the SiC device) is a real limit of the published data, disclosed
  here rather than papered over with an invented SiC Foster network.

  Device rated current (400A IGBT, 350A SiC) still vastly exceeds this
  design's ~8-30A per-cell operating current (same disclosed oversizing
  as before, driven by 3300V MV blocking voltage, not current), so the
  self-heating found below is small -- an expected, honestly-reported
  consequence of that oversizing, not a target the electro-thermal loop
  was tuned to hit.

Loss methodology (disclosed simplifications, updated):
  - Conduction loss now uses a TEMPERATURE-DEPENDENT constant-drop model
    for the IGBT bridges (Vce,sat(Tj), piecewise-linearly interpolated
    between the datasheet's 25/125 degC typical points, flat-extrapolated
    beyond) and a temperature-dependent constant-Rds(on) (I^2R) model for
    the SiC MOSFET bridge (Rds,on(Tj), interpolated between the datasheet's
    25/150 degC points). This is a CURRENT-independent (still first-order)
    but now TEMPERATURE-dependent piecewise model -- a genuine step up from
    the original single-point constant, but still not a full nonlinear
    current-dependent V-I curve fit: neither manufacturer datasheet
    publishes tabulated output-characteristic (Vce vs Ic) curve points at
    multiple currents, only a graphical figure, so digitizing a true 2-D
    V-I surface is not possible from the data actually retrieved here.
    This scope limit is disclosed rather than papered over with invented
    curve points.
  - Switching loss scales the TEMPERATURE-INTERPOLATED datasheet Eon/Eoff
    by (V_blocked/V_test)*(I_at_event/I_test), the same linear
    voltage/current scaling as before, now evaluated at each device's own
    converged junction temperature rather than a fixed 25 degC set.
  - Electro-thermal convergence: each device's steady-state junction
    temperature is found by iterating Tj_(n+1) = Tc + P_loss(Tj_n)*Rth(j-c)
    to a fixed point, where Rth(j-c) is the manufacturer's own steady-state
    total (sum of the Foster network's ri branches for the IGBT/diode;
    the single published value for the SiC MOSFET). Tc (case/heatsink
    temperature) is a disclosed DESIGN ASSUMPTION -- 60 degC, a
    representative forced-air/liquid-cooled MV converter enclosure
    operating point -- not a measured or datasheet value, since real
    heatsink/coolant thermal design is out of scope here.
  - The DAB's own confirmed ZVS condition (sst_dab_model.py's
    zvs_margin(), already holding at the rated d=0.35 operating point) is
    applied by zeroing Eon for both DAB bridges, since ZVS removes the
    voltage-current overlap and device-capacitance turn-on loss; Eoff is
    kept because IGBT tail current and SiC MOSFET turn-off loss are not
    eliminated by ZVS. The CHB stage is hard-switched (no ZVS claim is
    made for it anywhere in this paper), so both Eon and Eoff are charged
    there.
  - Loss is assumed evenly split across a bridge's 4 physical switch
    positions for the purposes of the per-device thermal estimate, since
    the loss model itself (like the switching-energy accounting above)
    does not separately track which physical device (IGBT vs. antiparallel
    diode, or which of the 4 positions) carries current at each instant --
    the same balanced/complementary-switching assumption already used for
    the loss accounting itself.
"""
import numpy as np
import json
import sst_chb_model as chb
import sst_dab_model as dab

# --- Device parameters: temperature breakpoints from the FULL datasheets
#     (see module docstring for the correction from the earlier short-form
#     catalog figures) ---
IGBT_T_BP = [25.0, 125.0]              # degC
IGBT_VCESAT_BP = [4.25, 4.30]          # V, typ (IC=400A, VGE=15V)
IGBT_EON_BP = [0.470, 0.730]           # J
IGBT_EOFF_BP = [0.430, 0.510]          # J
IGBT_V_TEST = 1800.0                   # V (now a CONFIRMED datasheet test
                                        # condition, not a disclosed guess)
IGBT_I_TEST = 400.0                    # A

# Infineon FF400R33KF2C Foster thermal network (junction-to-case), IGBT and
# diode, from the full datasheet's ZthJC transient table.
IGBT_FOSTER_R = [11.7e-3, 6.5e-3, 1.56e-3, 6.24e-3]   # K/W (datasheet: K/kW)
IGBT_FOSTER_TAU = [0.03, 0.1, 0.3, 1.0]                # s
RTH_JC_IGBT = float(np.sum(IGBT_FOSTER_R))             # = 0.026 K/W, matches
                                                        # the short-form
                                                        # catalog's steady-
                                                        # state figure exactly

SIC_T_BP = [25.0, 125.0, 150.0]        # degC
SIC_RDSON_BP_T = [25.0, 150.0]
SIC_RDSON_BP = [4.0e-3, 6.5e-3]        # ohm (VGS=15V, ID=350A)
SIC_EON_BP = [5.0e-3, 4.5e-3, 4.4e-3]  # J
SIC_EOFF_BP = [4.8e-3, 4.8e-3, 4.9e-3]  # J
SIC_V_TEST = 600.0                     # V
SIC_I_TEST = 350.0                     # A
RTH_JC_SIC = 0.116                     # K/W, steady-state only (Wolfspeed
                                        # publishes graphical Zth curves, not
                                        # tabulated Foster coefficients)

TC_ASSUMED = 60.0    # degC, disclosed case/heatsink design-point assumption


def _interp(tj, t_bp, v_bp):
    return float(np.interp(tj, t_bp, v_bp))


def foster_step_response(p_w, r_list, tau_list, t):
    """Junction-to-case temperature RISE (degC) above the case temperature,
    t seconds after a step to constant loss p_w, from the manufacturer's own
    multi-branch Foster RC network -- the standard closed-form step response
    of a Foster ladder, dT(t) = P * sum_i r_i*(1-exp(-t/tau_i))."""
    return p_w * sum(r * (1.0 - np.exp(-np.asarray(t) / tau)) for r, tau in zip(r_list, tau_list))


def chb_cell_loss(vcesat=None, eon_ref=None, eoff_ref=None):
    """Re-uses sst_chb_model's own production run (N_SUB=1600, the same
    converged resolution reported in Section IV-A) and layers device loss
    accounting on cell 0's own two-leg PWM state, detected directly from
    the same carrier()/reference logic used to build the stack waveform.
    vcesat/eon_ref/eoff_ref default to the 25 degC datasheet values but can
    be overridden with temperature-interpolated values for the electro-
    thermal iteration below."""
    if vcesat is None:
        vcesat = IGBT_VCESAT_BP[0]
    if eon_ref is None:
        eon_ref = IGBT_EON_BP[0]
    if eoff_ref is None:
        eoff_ref = IGBT_EOFF_BP[0]

    t_log, ig_log, vstack_log, vgrid_log = chb.run_sim()
    V1 = chb.V1

    vref = chb.MA * np.sin(chb.W1 * t_log + chb.DELTA)
    c = chb.carrier(t_log, 0.0)          # cell 0, zero phase shift
    s1 = (vref > c).astype(np.float64)
    s2 = ((-vref) > c).astype(np.float64)
    dt = chb.DT
    i = ig_log

    # conduction: an H-bridge always has exactly one device conducting per
    # leg (2 devices total) carrying |i|, regardless of PWM state
    e_cond = float(np.sum(2.0 * vcesat * np.abs(i)) * dt)

    def switching_energy(state):
        # each transition of a leg's binary state is a simultaneous
        # commutation of its two complementary devices: the incoming
        # device switches on (Eon) while the outgoing device switches off
        # (Eoff) at the same instant, so the combined (Eon+Eoff) energy is
        # charged once per transition, in EITHER direction -- summed over
        # a full period this correctly gives one full (Eon+Eoff) charged
        # to each of the two physical devices in the leg
        idx = np.nonzero(np.diff(state) != 0)[0]
        i_evt = np.abs(i[idx])
        scale = (V1 / IGBT_V_TEST) * (i_evt / IGBT_I_TEST)
        return float(np.sum((eon_ref + eoff_ref) * scale)), len(idx)

    e_sw1, n1 = switching_energy(s1)
    e_sw2, n2 = switching_energy(s2)
    e_sw = e_sw1 + e_sw2
    n_events = n1 + n2

    t_span = float(t_log[-1] - t_log[0] + dt)
    p_cond = e_cond / t_span
    p_sw = e_sw / t_span
    p_loss = p_cond + p_sw
    # each leg transitions twice per carrier period (once per polarity), so
    # the measured per-leg transition rate should land at 2x FSW_CELL --
    # this is a self-consistency check on the detected switching sequence,
    # not an independent design parameter
    measured_leg_transition_rate = n_events / 2.0 / t_span
    return dict(p_cond_W=p_cond, p_sw_W=p_sw, p_loss_W=p_loss,
                n_switching_events=n_events,
                measured_leg_transition_rate_Hz=measured_leg_transition_rate)


def dab_cell_loss(vcesat=None, eon_igbt=None, eoff_igbt=None,
                   rdson=None, eon_sic=None, eoff_sic=None):
    """Re-uses sst_dab_model's own rated-point switched simulation
    (d=0.35, the same operating point reported in Section IV-B) and
    layers device loss accounting on both bridges, applying the already-
    confirmed ZVS condition from zvs_margin(). Device parameters default
    to the 25 degC datasheet values but can be overridden with temperature-
    interpolated values for the electro-thermal iteration below."""
    if vcesat is None:
        vcesat = IGBT_VCESAT_BP[0]
    if eon_igbt is None:
        eon_igbt = IGBT_EON_BP[0]
    if eoff_igbt is None:
        eoff_igbt = IGBT_EOFF_BP[0]
    if rdson is None:
        rdson = SIC_RDSON_BP[0]
    if eon_sic is None:
        eon_sic = SIC_EON_BP[0]
    if eoff_sic is None:
        eoff_sic = SIC_EOFF_BP[0]

    p_avg, i_pkpk, i_log, v1_log, v2_log, t_log = dab.simulate_dab(
        dab.D_RATED, Lk=dab.LK, n_periods=64, steps_per_period=4000)
    dt = t_log[1] - t_log[0]
    V1 = dab.V1_NOM
    V2 = dab.V2_NOM
    n = dab.N_TURNS

    i0, i_shift = dab.zvs_margin(dab.D_RATED)
    zvs_ok = bool(i0 < 0 and i_shift > 0)   # both bridges' ZVS condition

    # --- primary bridge (IGBT, 3300 V, actual primary current = i_log) ---
    i_prim = i_log
    e_cond_prim = float(np.sum(2.0 * vcesat * np.abs(i_prim)) * dt)
    idx1 = np.nonzero(np.diff(v1_log) != 0)[0]
    i_evt1 = np.abs(i_prim[idx1])
    eon1 = 0.0 if zvs_ok else eon_igbt     # ZVS removes turn-on loss
    scale1 = (V1 / IGBT_V_TEST) * (i_evt1 / IGBT_I_TEST)
    e_sw_prim = float(np.sum((eon1 + eoff_igbt) * scale1))

    # --- secondary bridge (SiC MOSFET, 800 V actual, actual secondary
    #     current = n * i_log since the transformer secondary carries n x
    #     the primary-referred current) ---
    i_sec = n * i_log
    e_cond_sec = float(np.sum(2.0 * rdson * i_sec ** 2) * dt)
    idx2 = np.nonzero(np.diff(v2_log) != 0)[0]
    i_evt2 = np.abs(i_sec[idx2])
    eon2 = 0.0 if zvs_ok else eon_sic
    scale2 = (V2 / SIC_V_TEST) * (i_evt2 / SIC_I_TEST)
    e_sw_sec = float(np.sum((eon2 + eoff_sic) * scale2))

    t_span = float(t_log[-1] - t_log[0] + dt)
    p_cond = (e_cond_prim + e_cond_sec) / t_span
    p_sw = (e_sw_prim + e_sw_sec) / t_span
    p_loss = p_cond + p_sw
    return dict(zvs_applied=zvs_ok,
                p_cond_primary_W=e_cond_prim / t_span,
                p_cond_secondary_W=e_cond_sec / t_span,
                p_sw_primary_W=e_sw_prim / t_span,
                p_sw_secondary_W=e_sw_sec / t_span,
                p_cond_W=p_cond, p_sw_W=p_sw, p_loss_W=p_loss,
                n_switching_events_primary=len(idx1),
                n_switching_events_secondary=len(idx2))


# ---------------------------------------------------------------------
# Electro-thermal convergence: find each device's self-consistent steady-
# state Tj by iterating loss -> Tj -> temperature-dependent parameters ->
# loss, to a fixed point. Loss is split evenly across a bridge's 4 physical
# switch positions for this per-device estimate (see module docstring).
# ---------------------------------------------------------------------
def solve_chb_electrothermal(tc=TC_ASSUMED, tj0=25.0, tol=1e-4, max_iter=50):
    tj = tj0
    loss = None
    for _ in range(max_iter):
        vcesat = _interp(tj, IGBT_T_BP, IGBT_VCESAT_BP)
        eon = _interp(tj, IGBT_T_BP, IGBT_EON_BP)
        eoff = _interp(tj, IGBT_T_BP, IGBT_EOFF_BP)
        loss = chb_cell_loss(vcesat, eon, eoff)
        p_per_device = loss["p_loss_W"] / 4.0   # 4 switch positions/cell
        tj_new = tc + p_per_device * RTH_JC_IGBT
        if abs(tj_new - tj) < tol:
            tj = tj_new
            break
        tj = tj_new
    return dict(tj_C=tj, vcesat_V=vcesat, eon_J=eon, eoff_J=eoff,
                p_per_device_W=p_per_device, loss=loss)


def solve_dab_electrothermal(tc=TC_ASSUMED, tj0=25.0, tol=1e-4, max_iter=50):
    tj_igbt, tj_sic = tj0, tj0
    loss = None
    for _ in range(max_iter):
        vcesat = _interp(tj_igbt, IGBT_T_BP, IGBT_VCESAT_BP)
        eon_i = _interp(tj_igbt, IGBT_T_BP, IGBT_EON_BP)
        eoff_i = _interp(tj_igbt, IGBT_T_BP, IGBT_EOFF_BP)
        rdson = _interp(tj_sic, SIC_RDSON_BP_T, SIC_RDSON_BP)
        eon_s = _interp(tj_sic, SIC_T_BP, SIC_EON_BP)
        eoff_s = _interp(tj_sic, SIC_T_BP, SIC_EOFF_BP)
        loss = dab_cell_loss(vcesat, eon_i, eoff_i, rdson, eon_s, eoff_s)
        p_igbt_per_device = (loss["p_cond_primary_W"] + loss["p_sw_primary_W"]) / 4.0
        p_sic_per_device = (loss["p_cond_secondary_W"] + loss["p_sw_secondary_W"]) / 4.0
        tj_igbt_new = tc + p_igbt_per_device * RTH_JC_IGBT
        tj_sic_new = tc + p_sic_per_device * RTH_JC_SIC
        if abs(tj_igbt_new - tj_igbt) < tol and abs(tj_sic_new - tj_sic) < tol:
            tj_igbt, tj_sic = tj_igbt_new, tj_sic_new
            break
        tj_igbt, tj_sic = tj_igbt_new, tj_sic_new
    return dict(tj_igbt_C=tj_igbt, tj_sic_C=tj_sic, vcesat_V=vcesat,
                eon_igbt_J=eon_i, eoff_igbt_J=eoff_i, rdson_ohm=rdson,
                eon_sic_J=eon_s, eoff_sic_J=eoff_s,
                p_igbt_per_device_W=p_igbt_per_device,
                p_sic_per_device_W=p_sic_per_device, loss=loss)


if __name__ == "__main__":
    N_CELLS_TOTAL = chb.N_CELLS * chb.N_PHASES if hasattr(chb, "N_PHASES") else 9
    P_CELL = dab.P_CELL

    # --- baseline (fixed 25 degC parameters, matching the paper's original
    #     Table III methodology, now using the CORRECTED datasheet values) ---
    chb_loss_25c = chb_cell_loss()
    dab_loss_25c = dab_cell_loss()
    chb_eff_25c = 1.0 - chb_loss_25c["p_loss_W"] / P_CELL
    dab_eff_25c = 1.0 - dab_loss_25c["p_loss_W"] / P_CELL

    # --- electro-thermal converged operating point ---
    chb_et = solve_chb_electrothermal()
    dab_et = solve_dab_electrothermal()
    chb_eff_et = 1.0 - chb_et["loss"]["p_loss_W"] / P_CELL
    dab_eff_et = 1.0 - dab_et["loss"]["p_loss_W"] / P_CELL

    print("=== CHB cell: fixed-25degC vs. electro-thermal-converged ===")
    print(f"  fixed 25degC:  Vce,sat={IGBT_VCESAT_BP[0]:.2f}V  loss={chb_loss_25c['p_loss_W']:.2f}W  "
          f"eff={100*chb_eff_25c:.3f}%")
    print(f"  converged:     Tj={chb_et['tj_C']:.2f}degC (Tc={TC_ASSUMED:.0f}degC)  "
          f"Vce,sat={chb_et['vcesat_V']:.3f}V  loss={chb_et['loss']['p_loss_W']:.2f}W  "
          f"eff={100*chb_eff_et:.3f}%")

    print("\n=== DAB cell: fixed-25degC vs. electro-thermal-converged ===")
    print(f"  fixed 25degC:  Vce,sat={IGBT_VCESAT_BP[0]:.2f}V  Rds,on={SIC_RDSON_BP[0]*1e3:.2f}mOhm  "
          f"loss={dab_loss_25c['p_loss_W']:.2f}W  eff={100*dab_eff_25c:.3f}%")
    print(f"  converged:     Tj_igbt={dab_et['tj_igbt_C']:.2f}degC  Tj_sic={dab_et['tj_sic_C']:.2f}degC  "
          f"Rds,on={dab_et['rdson_ohm']*1e3:.3f}mOhm  loss={dab_et['loss']['p_loss_W']:.2f}W  "
          f"eff={100*dab_eff_et:.3f}%")

    # --- Foster-network transient step response, at each device's own
    #     converged steady loss, for the paper's thermal-transient figure ---
    t_step = np.linspace(0, 5.0, 500)
    chb_p_per_device = chb_et["p_per_device_W"]
    dtj_chb = foster_step_response(chb_p_per_device, IGBT_FOSTER_R, IGBT_FOSTER_TAU, t_step)
    dab_p_igbt_per_device = dab_et["p_igbt_per_device_W"]
    dtj_dab_igbt = foster_step_response(dab_p_igbt_per_device, IGBT_FOSTER_R, IGBT_FOSTER_TAU, t_step)
    # SiC: no published multi-branch network, so a single-exponential
    # equivalent using the published steady-state Rth(j-c) and (disclosed)
    # a representative thermal time constant of 0.3s (mid-range of the
    # IGBT's own tau spread, since no SiC-specific tau is published) is
    # shown ONLY as a qualitative shape indicator, explicitly flagged as
    # such rather than presented as a manufacturer-sourced curve.
    dtj_dab_sic = dab_et["p_sic_per_device_W"] * RTH_JC_SIC * (1 - np.exp(-t_step / 0.3))

    combined_new_stages_25c = chb_eff_25c * dab_eff_25c
    combined_new_stages_et = chb_eff_et * dab_eff_et
    lv_inverter_eff = 0.98
    full_sst_25c = combined_new_stages_25c * lv_inverter_eff
    full_sst_et = combined_new_stages_et * lv_inverter_eff

    print(f"\nCHB+DAB combined: fixed-25degC={100*combined_new_stages_25c:.3f}%  "
          f"electro-thermal-converged={100*combined_new_stages_et:.3f}%")
    print(f"Full SST (LV inverter lit.): fixed-25degC={100*full_sst_25c:.3f}%  "
          f"electro-thermal-converged={100*full_sst_et:.3f}%")
    print(f"\nSteady-state Tj rise above Tc={TC_ASSUMED:.0f}degC case temperature: "
          f"CHB IGBT +{chb_et['tj_C']-TC_ASSUMED:.2f}degC, "
          f"DAB primary IGBT +{dab_et['tj_igbt_C']-TC_ASSUMED:.2f}degC, "
          f"DAB secondary SiC +{dab_et['tj_sic_C']-TC_ASSUMED:.2f}degC "
          f"-- small, as expected given how heavily current-oversized both "
          f"modules are for this design's operating current.")

    out = dict(
        igbt_device="Infineon FF400R33KF2C (3300V/400A Si IGBT dual module)",
        sic_device="Wolfspeed WAS350M12BM3 (1200V/350A SiC MOSFET half-bridge module)",
        tc_assumed_C=TC_ASSUMED,
        fixed_25C=dict(
            chb_cell=chb_loss_25c, dab_cell=dab_loss_25c,
            chb_stage_eff_pct=round(100 * chb_eff_25c, 3),
            dab_stage_eff_pct=round(100 * dab_eff_25c, 3),
            combined_new_stages_eff_pct=round(100 * combined_new_stages_25c, 3),
            full_sst_eff_pct=round(100 * full_sst_25c, 3),
        ),
        electrothermal_converged=dict(
            chb_tj_C=round(chb_et["tj_C"], 2),
            dab_tj_igbt_C=round(dab_et["tj_igbt_C"], 2),
            dab_tj_sic_C=round(dab_et["tj_sic_C"], 2),
            chb_cell=chb_et["loss"], dab_cell=dab_et["loss"],
            chb_stage_eff_pct=round(100 * chb_eff_et, 3),
            dab_stage_eff_pct=round(100 * dab_eff_et, 3),
            combined_new_stages_eff_pct=round(100 * combined_new_stages_et, 3),
            full_sst_eff_pct=round(100 * full_sst_et, 3),
        ),
        rth_jc_igbt_K_per_W=round(RTH_JC_IGBT, 5),
        rth_jc_sic_K_per_W=RTH_JC_SIC,
        lv_inverter_eff_pct_literature=98.0,
        # backward-compatible top-level keys (electro-thermal-converged
        # values, the new production numbers used throughout the paper)
        chb_stage_eff_pct=round(100 * chb_eff_et, 3),
        dab_stage_eff_pct=round(100 * dab_eff_et, 3),
        combined_new_stages_eff_pct=round(100 * combined_new_stages_et, 3),
        full_sst_eff_pct=round(100 * full_sst_et, 3),
    )
    with open("sst_losses_results.json", "w") as f:
        json.dump(out, f, indent=2)
    np.savez("sst_thermal_step.npz", t=t_step, dtj_chb=dtj_chb,
             dtj_dab_igbt=dtj_dab_igbt, dtj_dab_sic=dtj_dab_sic)
    print("\nSaved sst_losses_results.json and sst_thermal_step.npz")
