"""
SST paper -- techno-economic / battery-lifecycle comparative analysis
(new Section 6.7). Reviewer ask: quantify how the SST's ride-through
advantage (Section 6.5's Monte Carlo trip-rate gap, Section 6.6's joint
dispatch-excursion finding) offsets its own disclosed 2.69-percentage-
point efficiency penalty (Section 6.3), via avoided BESS cycle-stress
cost and avoided downtime cost, against the SST's own higher capital
cost.

Every unit-cost figure below is a REAL, cited external source (see the
paper's References [14]-[16]), not a number invented for this paper --
but combining them into a single $/event or breakeven figure for THIS
specific 150 kVA design necessarily layers several DISCLOSED simplifying
assumptions on top of those real anchors (documented inline below). This
script produces a BOUNDING / breakeven sensitivity, not a claim of a
precise annual savings figure -- the available sources do not support
that level of precision, and this script does not pretend otherwise.

Sources:
  [14] SST vs. conventional transformer capital cost: a 2022 Sustainability
       review (Yaqoob et al.) reports SST "cost of production" of
       USD 1000-2000 for a 20 kVA, 7.2kV-120V unit (~USD 50-100/kVA),
       against a USD 1500 MARKET price for a 25 kVA conventional pole-
       mount transformer (~USD 60/kVA) -- comparable order-of-magnitude
       at this SMALL scale, though the review's own qualitative
       conclusion is that SST capital cost is currently "much higher"
       than conventional once markup/installation/enclosure (not
       included in the bare production-cost figure) are added. This
       paper's own 150 kVA design is far closer to distribution scale
       than that 20-25 kVA example, so this data point is used only to
       BOUND a plausible incremental-cost sensitivity (a low bound taken
       directly from the review's own numbers, a high bound consistent
       with its qualitative "much higher" finding), not asserted as this
       design's own quoted price.
  [15] NREL ATB 2024/2025 (Cost Projections for Utility-Scale Battery
       Storage): 4-hour Li-ion BESS installed cost USD 334/kWh (2024$);
       15-year assumed lifetime at ~1 cycle/day (~5475 cycles).
       Repurposed here (a disclosed simplification -- the ATB's own
       methodology is calendar-life/FOM-based, not a pure cycle-life
       figure) into a standard equivalent-full-cycle (EFC) replacement
       cost: cost_per_EFC = (cost_per_kWh * usable_kWh) / cycle_life.
  [16] LBNL-6941E (Sullivan, Schellenberg & Blundell, 2015): medium/large
       commercial & industrial customer interruption cost, MOMENTARY
       (<5 min) interruption = USD 15.9 per average kW interrupted,
       2013$ (NOT inflation-adjusted here -- a disclosed, conservative
       choice that makes the dollar figures below understated in
       present terms, not overstated).
  EIA (2024, Table 4): average US commercial retail electricity price
       USD 0.1275/kWh -- used only for the separate "cost of the
       efficiency penalty itself" comparison, not the avoided-cost side.
"""
import json
import numpy as np

# --- [14] SST capital-cost sensitivity bounds ($/kVA premium over conventional) ---
# The review's own reported range actually straddles zero premium at its
# LOW end ($50/kVA SST vs. $60/kVA conventional -- SST would be CHEAPER
# there), which is not a useful "low bound" for a premium sensitivity. So
# the low bound here instead uses the review's own HIGH production-cost
# figure against the conventional price (a genuine, still literature-
# sourced positive premium), and the high bound reflects the review's
# separate QUALITATIVE conclusion that deployed SST cost runs "much
# higher" than conventional once markup/installation are added (taken
# here, disclosed, as a representative ~3x conventional price).
SST_KVA_LOW, SST_KVA_HIGH = 50.0, 100.0     # review's own production-cost range
CONV_KVA = 60.0                              # review's conventional market price
PREMIUM_LOW_PER_KVA = max(SST_KVA_HIGH - CONV_KVA, 0.0)    # $/kVA, review's own numbers (low bound)
PREMIUM_HIGH_PER_KVA = 3.0 * CONV_KVA - CONV_KVA           # $/kVA, "much higher" (~3x) qualitative bound
RATING_KVA = 150.0
CAPEX_PREMIUM_LOW = PREMIUM_LOW_PER_KVA * RATING_KVA
CAPEX_PREMIUM_HIGH = PREMIUM_HIGH_PER_KVA * RATING_KVA

# --- [15] Battery equivalent-full-cycle (EFC) replacement cost ---
BESS_COST_PER_KWH = 334.0     # 2024$, NREL ATB, 4-hr duration
BESS_E_NAMEPLATE_KWH = 200.0
SOC_MIN, SOC_MAX = 20.0, 90.0
USABLE_KWH = BESS_E_NAMEPLATE_KWH * (SOC_MAX - SOC_MIN) / 100.0   # 140 kWh
CYCLE_LIFE = 5475             # NREL ATB, ~1 cycle/day over 15-yr lifetime
COST_PER_EFC = BESS_COST_PER_KWH * USABLE_KWH / CYCLE_LIFE

# --- [16] Momentary-interruption avoided-downtime cost ---
LBNL_MOMENTARY_USD_PER_KW = 15.9    # 2013$, medium/large C&I
INTERCONNECTION_KW = 150.0           # this design's own rated interconnection capacity,
                                      # used as the "average kW interrupted" basis
                                      # (a disclosed approximation, not a site-specific survey)
AVOIDED_DOWNTIME_PER_EVENT = LBNL_MOMENTARY_USD_PER_KW * INTERCONNECTION_KW

# --- EIA: cost of the efficiency penalty itself ---
EIA_COMMERCIAL_USD_PER_KWH = 0.1275   # 2024, US average commercial retail
PV_KWP = 100.0
PV_CAPACITY_FACTOR = 0.20             # disclosed representative assumption
ANNUAL_PV_ENERGY_KWH = PV_KWP * PV_CAPACITY_FACTOR * 8760.0
EFF_SST_PCT, EFF_CONV_PCT = 94.31, 97.00
EXTRA_LOSS_FRACTION = (EFF_CONV_PCT - EFF_SST_PCT) / 100.0
ANNUAL_EXTRA_LOSS_KWH = ANNUAL_PV_ENERGY_KWH * EXTRA_LOSS_FRACTION
ANNUAL_EFFICIENCY_PENALTY_USD = ANNUAL_EXTRA_LOSS_KWH * EIA_COMMERCIAL_USD_PER_KWH


def extra_dispatch_energy_kwh(policy):
    """Integrates the ALREADY-SIMULATED joint DQN/interface evaluation logs
    (Section 6.6, sst_dqn_joint_logs.npz) to find the EXTRA BESS discharge
    energy the conventional interface's trip response delivers relative to
    the SST interface's (near-flat) response, over the same logged event
    window -- the real, measured mechanism behind "avoided battery
    stress", not an assumed number."""
    d = np.load("sst_dqn_joint_logs.npz")
    t_conv = d[f"conventional_{policy}_t"]
    p_conv = d[f"conventional_{policy}_pbess"]
    t_sst = d[f"sst_{policy}_t"]
    p_sst = d[f"sst_{policy}_pbess"]
    # common time base (both logs share the same window/resolution by construction)
    assert len(t_conv) == len(t_sst) and np.allclose(t_conv, t_sst)
    dt = t_conv[1] - t_conv[0]
    extra_p = np.clip(p_conv - p_sst, 0, None)   # only the EXTRA discharge, kW
    extra_kwh = float(np.sum(extra_p) * dt / 3600.0)
    return extra_kwh


if __name__ == "__main__":
    print(f"Incremental SST capital cost (150 kVA): "
          f"${CAPEX_PREMIUM_LOW:,.0f} (low, ref. [14] production-cost figures) "
          f"to ${CAPEX_PREMIUM_HIGH:,.0f} (high, ref. [14]'s qualitative ~3x finding)")
    print(f"Battery EFC replacement cost: ${COST_PER_EFC:.2f} per equivalent full cycle "
          f"(usable capacity {USABLE_KWH:.0f} kWh, {CYCLE_LIFE} cycles, ${BESS_COST_PER_KWH:.0f}/kWh)")
    print(f"Avoided downtime cost per spared momentary trip: ${AVOIDED_DOWNTIME_PER_EVENT:,.2f} "
          f"(2013$, not inflation-adjusted)")
    print(f"Annual cost of the SST's own efficiency penalty: ${ANNUAL_EFFICIENCY_PENALTY_USD:,.0f}/yr "
          f"(at {ANNUAL_PV_ENERGY_KWH:,.0f} kWh/yr PV throughput, {PV_CAPACITY_FACTOR:.0%} capacity factor)")

    results = dict(
        capex_premium_usd_low=round(CAPEX_PREMIUM_LOW, 0),
        capex_premium_usd_high=round(CAPEX_PREMIUM_HIGH, 0),
        cost_per_efc_usd=round(COST_PER_EFC, 2),
        avoided_downtime_usd_per_event=round(AVOIDED_DOWNTIME_PER_EVENT, 2),
        annual_efficiency_penalty_usd=round(ANNUAL_EFFICIENCY_PENALTY_USD, 0),
        policies={},
    )

    for policy in ["pi", "dqn"]:
        extra_kwh = extra_dispatch_energy_kwh(policy)
        extra_efc = extra_kwh / USABLE_KWH
        avoided_battery_usd = extra_efc * COST_PER_EFC
        total_avoided_per_event = avoided_battery_usd + AVOIDED_DOWNTIME_PER_EVENT
        breakeven_events_low = CAPEX_PREMIUM_LOW / total_avoided_per_event
        breakeven_events_high = CAPEX_PREMIUM_HIGH / total_avoided_per_event
        print(f"\n=== {policy.upper()} policy, per-spared-trip-event during the shared 2s MV interruption ===")
        print(f"  Extra BESS discharge energy (conventional vs. SST): {extra_kwh:.3f} kWh "
              f"({extra_efc:.5f} equivalent full cycles)")
        print(f"  Avoided battery-stress cost: ${avoided_battery_usd:.4f}")
        print(f"  Avoided downtime cost: ${AVOIDED_DOWNTIME_PER_EVENT:,.2f}")
        print(f"  Total avoided cost per spared trip event: ${total_avoided_per_event:,.2f}")
        print(f"  Spared trip events to break even on capital premium: "
              f"{breakeven_events_low:,.1f} (low capex bound) - {breakeven_events_high:,.1f} (high capex bound)")
        results["policies"][policy] = dict(
            extra_dispatch_energy_kwh=round(extra_kwh, 3),
            extra_equivalent_full_cycles=round(extra_efc, 5),
            avoided_battery_stress_usd=round(avoided_battery_usd, 4),
            avoided_downtime_usd=round(AVOIDED_DOWNTIME_PER_EVENT, 2),
            total_avoided_usd_per_event=round(total_avoided_per_event, 2),
            breakeven_events_low=round(breakeven_events_low, 1),
            breakeven_events_high=round(breakeven_events_high, 1),
        )

    # Monte Carlo's own share of trials where the SST is spared a trip the
    # conventional interface suffers (Section 6.5, Table 5) -- reused
    # directly, not re-simulated, to report the RATE at which this
    # per-event saving would actually recur across a randomized disturbance
    # population (not an annual frequency claim -- see paper text/limits).
    with open("sst_montecarlo_results.json") as f:
        mc = json.load(f)
    spared_fraction = mc["n_conventional_only_trips"] / mc["n_trials"]
    print(f"\nMonte Carlo sweep (Section 6.5): the SST is spared a trip the "
          f"conventional interface suffers in {spared_fraction:.1%} of randomized trials "
          f"({mc['n_conventional_only_trips']}/{mc['n_trials']}).")
    results["monte_carlo_spared_trip_fraction"] = round(spared_fraction, 4)

    with open("sst_economics_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nSaved sst_economics_results.json")
