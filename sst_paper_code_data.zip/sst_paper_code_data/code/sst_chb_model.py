"""
SST paper -- Stage 1 (MV AC <-> MV DC) switching-resolution model: a 3-cell
cascaded H-bridge (CHB) per phase, phase-shifted-carrier (PSC) unipolar PWM,
and the resulting MV-side (11 kV) grid current total demand distortion
(TDD), checked against IEEE 519-2022 -- in the same spirit as the author's
prior digest's grid-tie VSC model (sst_dab_model.py header / vsc_model.py),
but for the SST's multilevel MV-side stage instead of a 2-level bridge.

Scope and disclosed assumptions:
  - Each phase's 3 series H-bridge cells are assumed identical and balanced
    (same DC-link V1=3300 V, same PSC-PWM reference), so only one phase is
    simulated; the other two are identical at +-120 deg, standard practice.
  - The multilevel waveform's superior harmonic profile needs only a small
    series filter inductor Ls (2% pu) at the MV side, not the full LCL
    filter the prior digest's 2-level grid-tie VSC required (8% pu
    converter-side + 20%-of-that grid-side) -- this is disclosed as a
    property of the multilevel topology, not an arbitrarily looser design
    target.
  - MV-side short-circuit level is estimated at a representative 250 MVA
    (typical urban 11 kV feeder fault level), not measured utility data --
    disclosed explicitly, exactly as the prior digest's LV-side Isc
    estimate was.
  - Each cell's own DC link (the input to that cell's dedicated DAB,
    sst_dab_model.py) is held at its nominal 3300 V for this MV-side
    current-quality study; DC-link ripple feedback into MV current
    distortion is a second-order effect not modeled here (disclosed).
"""
import numpy as np
import json

N_CELLS = 3
V1 = 3300.0                 # V, per-cell DC link
S_TOTAL = 150e3              # VA
VLL_MV = 11000.0             # V RMS, line-to-line MV
VPH_MV = VLL_MV / np.sqrt(3) # V RMS, phase (star point)
F1 = 50.0
W1 = 2 * np.pi * F1
FSW_CELL = 1e3                # Hz, per-cell carrier frequency. Originally set
                               # to 10 kHz "to match DAB fs" for pipeline
                               # consistency; sst_losses.py's switching-loss
                               # simulation (real Infineon FF400R33KF2C 3.3 kV
                               # IGBT data) showed that choice gives only
                               # 88.2% per-cell efficiency, since this device
                               # class is hard-switched here (unlike the
                               # ZVS DAB) and 10 kHz is well above what a
                               # 3.3 kV Si IGBT is normally switched at in
                               # practice. A sweep of FSW_CELL against both
                               # TDD and simulated loss (Section VI-C) found
                               # 1 kHz -- a standard carrier frequency for
                               # this device class in real MV multilevel
                               # converters -- recovers 98.6% per-cell
                               # efficiency while TDD is still only 0.56%,
                               # comfortably inside the 20% IEEE 519-2022
                               # limit. This revised value is used throughout.

S_PHASE = S_TOTAL / 3.0
I_RATED = S_TOTAL / (np.sqrt(3) * VLL_MV)   # A RMS, MV-side rated current
Z_BASE = VPH_MV ** 2 / S_PHASE
L_BASE = Z_BASE / W1

LS = 0.02 * L_BASE            # small MV-side series filter inductor (2% pu,
                               # vs. the prior digest's 8%+ LCL for its
                               # 2-level VSC -- the multilevel waveform's
                               # much lower switching-harmonic content is
                               # what allows this reduction)
RS = 0.01 * Z_BASE            # ohm, series resistance (1% pu -- feeder
                               # resistance + cell conduction drop combined;
                               # sized to give a fast enough L/R settling
                               # transient for the simulated window, not
                               # just the switching-ripple damping used in
                               # the LV VSC model)

# Fundamental phasor design (unity PF export, same method as the prior
# digest's VSC design): required inverter-side voltage magnitude and power
# angle to deliver I_RATED through Ls at unity PF with the MV grid.
V_INV_REAL = VPH_MV + RS * I_RATED
V_INV_IMAG = W1 * LS * I_RATED
V_INV_MAG = np.hypot(V_INV_REAL, V_INV_IMAG)
DELTA = np.arctan2(V_INV_IMAG, V_INV_REAL)
MA = (V_INV_MAG * np.sqrt(2)) / (N_CELLS * V1)   # modulation index (linear
                                    # region if <=1); CHB max fundamental
                                    # PEAK amplitude = N*V1, so the RMS
                                    # phasor magnitude above is converted to
                                    # peak via sqrt(2) before the ratio

# N_SUB convergence check (same numerical-artifact pattern documented in the
# prior digest's VSC model): a coarse N_SUB quantizes each PWM edge to the
# nearest Euler grid point, injecting spurious low-order content that is a
# discretization artifact, not a physical CHB harmonic -- confirmed by
# re-running at successively finer N_SUB and watching TDD converge toward
# zero (ideal PSC-PWM produces negligible baseband distortion by
# construction). At the revised FSW_CELL=1 kHz: N_SUB=400 -> TDD=1.55%,
# 800 -> 1.07%, 1600 -> 0.56%, 3200 -> 0.20%. N_SUB=1600 is used for the
# reported production result as a converged, runtime-reasonable choice; the
# true (N_SUB->inf) TDD is smaller still, so the compliance margin below is
# conservative. (At the original 10 kHz candidate the same sweep gave
# 0.973%/0.329%/0.116%/0.026% -- also compliant, but abandoned in favor of
# 1 kHz once the switching-loss simulation showed the efficiency cost of
# 10 kHz on this device class.)
N_SUB = 1600                        # sub-steps per cell carrier period
DT = 1.0 / (FSW_CELL * N_SUB)
N_CYCLES = 12
T_END = N_CYCLES / F1
N_STEPS = int(T_END / DT)


def carrier(t, phase_shift_frac):
    """Bipolar triangular carrier, amplitude +-1, frequency FSW_CELL, shifted
    by phase_shift_frac of one carrier period (0..1)."""
    phase = (t * FSW_CELL - phase_shift_frac) % 1.0
    return 4 * np.abs(phase - 0.5) - 1.0


def cell_output(vref, t, phase_shift_frac, v1=V1):
    """Unipolar PWM for one H-bridge cell: leg1 vs +vref, leg2 vs -vref,
    both against the SAME (phase-shifted) carrier -- standard PSC-PWM cell
    logic. Output in {-v1, 0, +v1}."""
    c = carrier(t, phase_shift_frac)
    s1 = 1.0 if vref > c else 0.0
    s2 = 1.0 if (-vref) > c else 0.0
    return v1 * (s1 - s2)


def run_sim():
    """Simulate phase-a's 3-cell CHB stack against a stiff MV grid through
    Ls, Rs. PSC-PWM: cell k's carrier is phase-shifted by k/N_CELLS of one
    carrier period (the standard scheme for 2N+1-level unipolar CHB)."""
    ig = 0.0
    t_log = np.zeros(N_STEPS)
    ig_log = np.zeros(N_STEPS)
    vstack_log = np.zeros(N_STEPS)
    vgrid_log = np.zeros(N_STEPS)
    for k in range(N_STEPS):
        t = k * DT
        vref = MA * np.sin(W1 * t + DELTA)
        vstack = sum(cell_output(vref, t, c / N_CELLS) for c in range(N_CELLS))
        vgrid = np.sqrt(2) * VPH_MV * np.sin(W1 * t)
        dig = (vstack - vgrid - RS * ig) / LS
        ig += dig * DT
        t_log[k] = t; ig_log[k] = ig; vstack_log[k] = vstack; vgrid_log[k] = vgrid
    return t_log, ig_log, vstack_log, vgrid_log


def thd_tdd(t_log, ig_log, i_rated):
    n_use_cycles = N_CYCLES // 2
    dt = t_log[1] - t_log[0]
    samples_per_cycle = int(round((1.0 / F1) / dt))
    n_use = n_use_cycles * samples_per_cycle
    ia = ig_log[-n_use:]
    n = len(ia)
    spec = np.fft.rfft(ia)
    mag = np.abs(spec) / n * 2.0
    f1_idx = int(round(F1 * n * dt))
    i1 = mag[f1_idx]
    harmonics = {h: mag[int(round(h * F1 * n * dt))] for h in range(2, 51)
                 if int(round(h * F1 * n * dt)) < len(mag)}
    thd_i = 100.0 * np.sqrt(sum(v ** 2 for v in harmonics.values())) / i1
    tdd = 100.0 * np.sqrt(sum(v ** 2 for v in harmonics.values())) / i_rated
    dom_h = max(harmonics, key=harmonics.get)
    return dict(i1_rms=i1 / np.sqrt(2), thd_i_pct=round(thd_i, 4), tdd_pct=round(tdd, 4),
                dominant_harmonic_order=dom_h,
                dominant_harmonic_pct_of_IL=round(100 * harmonics[dom_h] / i_rated, 5),
                freqs=np.fft.rfftfreq(n, d=dt), mag=mag)


def isc_il_estimate(s_fault_mva=250.0):
    isc = (s_fault_mva * 1e6) / (np.sqrt(3) * VLL_MV)
    return isc, I_RATED, isc / I_RATED


def ieee519_2022_tdd_limit(isc_il_ratio):
    table = [(20, 5.0), (50, 8.0), (100, 12.0), (1000, 15.0), (np.inf, 20.0)]
    for upper, limit in table:
        if isc_il_ratio < upper:
            return limit
    return 20.0


def n_level_count(n_cells=N_CELLS):
    return 2 * n_cells + 1


if __name__ == "__main__":
    print(f"MV-side rated current I_rated = {I_RATED:.3f} A RMS "
          f"(150 kVA / sqrt(3)/11 kV)")
    print(f"Filter: Ls = {LS*1e3:.3f} mH ({LS/L_BASE*100:.1f}% pu, base {L_BASE*1e3:.2f} mH)")
    print(f"Modulation: ma = {MA:.4f}, power angle delta = {np.degrees(DELTA):.3f} deg")
    print(f"Output levels: {n_level_count()} ({N_CELLS} series cells, +-{N_CELLS}*V1 = "
          f"+-{N_CELLS*V1:.0f} V)")

    t_log, ig_log, vstack_log, vgrid_log = run_sim()

    p_window = t_log > (T_END - 2.0 / F1)
    p_inst = vgrid_log[p_window] * ig_log[p_window]
    # 3-phase real power = 3x per-phase (balanced), matches S_TOTAL at unity PF
    p_avg_3ph = 3.0 * float(np.mean(p_inst))
    print(f"Delivered power (check): {p_avg_3ph/1e3:.2f} kW (target {S_TOTAL/1e3:.1f} kW, "
          f"{100*p_avg_3ph/S_TOTAL:.1f}%)")

    result = thd_tdd(t_log, ig_log, I_RATED)
    isc, il, ratio = isc_il_estimate()
    tdd_limit = ieee519_2022_tdd_limit(ratio)
    print(f"I1 RMS = {result['i1_rms']:.3f} A, THD_i = {result['thd_i_pct']:.4f}%, "
          f"TDD = {result['tdd_pct']:.4f}%")
    print(f"Dominant harmonic: h={result['dominant_harmonic_order']} "
          f"({result['dominant_harmonic_order']*F1:.0f} Hz), "
          f"{result['dominant_harmonic_pct_of_IL']:.5f}% of IL")
    print(f"Isc={isc:.0f} A (250 MVA fault level assumption), IL={il:.2f} A, "
          f"Isc/IL={ratio:.0f}, IEEE 519-2022 TDD limit={tdd_limit:.1f}%, "
          f"{'PASS' if result['tdd_pct'] <= tdd_limit else 'FAIL'}")

    out = dict(
        n_cells=N_CELLS, n_levels=n_level_count(), V1_V=V1, Ls_mH=round(LS * 1e3, 4),
        Ls_pu_pct=round(LS / L_BASE * 100, 2), ma=round(MA, 4),
        power_angle_deg=round(np.degrees(DELTA), 3), I_rated_A=round(I_RATED, 3),
        fsw_cell_Hz=FSW_CELL, delivered_power_kW=round(p_avg_3ph / 1e3, 3),
        delivered_power_pct_of_target=round(100 * p_avg_3ph / S_TOTAL, 2),
        thd_i_pct=result["thd_i_pct"], tdd_pct=result["tdd_pct"],
        i1_rms_A=round(result["i1_rms"], 3),
        dominant_harmonic_order=int(result["dominant_harmonic_order"]),
        dominant_harmonic_pct_of_IL=result["dominant_harmonic_pct_of_IL"],
        Isc_A=round(isc, 1), IL_A=round(il, 3), Isc_over_IL=round(ratio, 1),
        s_fault_mva_assumed=250.0,
        ieee519_tdd_limit_pct=tdd_limit,
        compliant=bool(result["tdd_pct"] <= tdd_limit),
    )
    with open("sst_chb_results.json", "w") as f:
        json.dump(out, f, indent=2)
    np.savez("sst_chb_waveform.npz", t=t_log, ig=ig_log, vstack=vstack_log, vgrid=vgrid_log,
             freqs=result["freqs"], mag=result["mag"])
    print("\nSaved sst_chb_results.json and sst_chb_waveform.npz")
