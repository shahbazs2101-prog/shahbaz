"""
SAPEC 2027 digest -- supervisory-level (reduced-order) system simulation and
DQN training.

Scope note (do not confuse this model with the Step 3-5 converter model):
this script is the SUPERVISORY-LAYER simulation only. It implements a
physically-motivated, reduced-order (average-model, energy-balance DC-bus)
simulation of the full architecture defined in the SAPEC Step 1 design
(100 kWp PV / 200 kWh-100 kW BESS / two-phase interleaved bidirectional
buck-boost converter / 800 V DC bus / 3-phase VSC / 60-120 kW load), trains
a real PyTorch DQN agent against it, and evaluates it head to head against
a conventional PI-based supervisory EMS baseline on a fixed 5-segment
scenario. All numbers reported downstream come from this executed code --
none are hand-picked or fabricated.

This is DELIBERATELY coarser than the Step 3-5 converter model: Steps 3-5
(sim/converter_model.py, sim/step5_validate.py) already implement and
validate a real SWITCHED-MODEL, PWM-resolution (400 samples/switching
period) simulation of the buck-boost converter itself -- individual
switching transitions, inductor ripple, and capacitor ripple are resolved
there and cross-checked against analytic targets to within 0.20%. That
switching-resolution detail is unnecessary (and computationally prohibitive)
at the 1 s supervisory decision interval used here, so this script uses an
average/slew-rate model of the converter's OUTPUT instead -- appropriate
because Step 5 already showed the converter's own closed-loop settling time
(~1 ms) is three orders of magnitude faster than this decision interval.
Switching-level AC-side harmonic content (THD at the PCC) is a property of
the GRID-TIE VSC, a separate converter neither this script nor Step 3-5
models at switching resolution; it is explicitly excluded from the reported
metrics and deferred to a future switching-level model of that VSC
(Simscape or an equivalent custom switched simulation, in the style of
Step 3's converter_model.py).
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
import json

rng = np.random.default_rng(7)
torch.manual_seed(7)
random.seed(7)

# ---------------------------------------------------------------------
# 1. System parameters (from the confirmed Step 1 architecture)
# ---------------------------------------------------------------------
PV_RATED = 100.0        # kW
BESS_E = 200.0          # kWh
BESS_P = 100.0          # kW
SOC_MIN, SOC_MAX = 20.0, 90.0
VDC_NOM = 800.0         # V
LOAD_MIN, LOAD_MAX = 60.0, 120.0

# Converter design (Sec. VI-derived): 2-phase interleaved buck-boost
L_PH = 1.1e-3           # H per phase
C_PH = 200e-6           # F per phase (bus side)
FSW = 10e3              # Hz per phase
KP_I, KI_I = 0.0084, 10.5   # current-loop PI gains (duty/A, duty/(A.s))
SLEW_MAX = 50.0         # kW/s converter/battery power slew limit
TRACK_ERR = 0.02        # 2% steady-state tracking error (inner PI loop)

# DC bus dynamics: the VSC's cascaded outer-voltage/inner-current loop is
# represented as an equivalent PI regulator acting directly on Vdc, driving
# AC-side power exchange to hold the bus at 800 V. Energy balance:
#   C*V*dV/dt = P_in(t) - P_vsc(t),   P_vsc = Kp_v*(V-800) + Ki_v*INTEGRAL[(V-800)dt]
# Gains below were calibrated (see converter-sizing derivation) so a full
# 60 kW power step produces a ~3% transient peak deviation settling to zero
# within ~100 ms -- consistent with typical grid-tie inverter DC-link
# regulation performance; this is NOT a claim of switching-level accuracy.
C_BUS_EQ = 2.0e-3    # F, effective bus capacitance (converter + VSC DC-link bank)
KP_V = 2000.0        # W/V, VSC equivalent voltage-loop proportional gain
KI_V = 2.0e5         # W/(V.s), VSC equivalent voltage-loop integral gain

# Static bus-voltage sensitivity proxy used ONLY at supervisory (1s) resolution
# for reward shaping / PI-baseline Vdc trim (linearized, not a real EMT model)
KV_SENS = 0.05  # V per kW of instantaneous power imbalance

# Cost model
PRICE_IMPORT = 0.12   # $/kWh
PRICE_EXPORT = 0.06   # $/kWh
DEGRADATION_COST = 0.05  # $/kWh throughput

# Action set: discrete BESS power reference, kW.
# Sign convention: POSITIVE = discharging (BESS -> bus), NEGATIVE = charging (bus -> BESS)
# Resolution: 21 levels in 10 kW steps (previously 9 levels / 25 kW steps). 10 kW
# was chosen as the finest grid that still keeps the action count small enough for
# stable tabular-style Q-value estimation with a 64-64 MLP (21 outputs) while cutting
# the discretization quantum (and hence the theoretical worst-case per-step tracking
# error) by 2.5x relative to the original 25 kW grid.
ACTIONS = np.array([-100, -90, -80, -70, -60, -50, -40, -30, -20, -10, 0,
                     10, 20, 30, 40, 50, 60, 70, 80, 90, 100], dtype=float)
N_ACTIONS = len(ACTIONS)

DT_DEC = 1.0       # s, supervisory decision interval (both PI and DQN)
DT_FINE = 0.0002   # s, fine-resolution step for bus-dynamics evaluation
                   # (matches the step size used to calibrate KP_V/KI_V for
                   # numerical stability of the explicit Euler update)

# ---------------------------------------------------------------------
# 2. Scenario generator: 5 back-to-back 600 s segments (3000 s total)
#    normal -> PV disturbance -> load disturbance -> SOC-boundary -> grid disturbance
# ---------------------------------------------------------------------
SEG_LEN = 600
SEGMENTS = ["normal", "pv_disturbance", "load_disturbance", "soc_boundary", "grid_disturbance"]


def profile(seg_name, t_local, rng_local, soc_force=None):
    """Return (Ppv_kW, Pload_kW, grid_available) at local time t_local within a segment."""
    grid_ok = True
    if seg_name == "normal":
        irr = 700 + 150 * np.sin(2 * np.pi * t_local / 600) + rng_local.normal(0, 8)
        irr = np.clip(irr, 0, 1000)
        pv = PV_RATED * irr / 1000
        load = 90 + 10 * np.sin(2 * np.pi * t_local / 300) + rng_local.normal(0, 2)
    elif seg_name == "pv_disturbance":
        # cloud transients: fast drops/ramps in irradiance
        base = 900
        cloud = -600 if (150 < t_local < 220 or 400 < t_local < 480) else 0
        irr = np.clip(base + cloud + rng_local.normal(0, 15), 0, 1000)
        pv = PV_RATED * irr / 1000
        load = 85 + rng_local.normal(0, 2)
    elif seg_name == "load_disturbance":
        pv = PV_RATED * 0.75 + rng_local.normal(0, 5)
        step = 40 if (100 < t_local < 300) else 0
        fast = 20 * (1 if int(t_local) % 60 < 5 else 0)
        load = np.clip(70 + step + fast + rng_local.normal(0, 2), LOAD_MIN, LOAD_MAX)
    elif seg_name == "soc_boundary":
        # push toward SOC limits: strong sustained PV excess then sustained deficit
        pv = PV_RATED * (0.95 if t_local < 300 else 0.05) + rng_local.normal(0, 3)
        load = 60 if t_local < 300 else 118
        pv = max(pv, 0)
    elif seg_name == "grid_disturbance":
        pv = PV_RATED * 0.6 + rng_local.normal(0, 5)
        load = 95 + rng_local.normal(0, 2)
        grid_ok = not (250 < t_local < 300)  # simulated PCC voltage loss / islanding window
    else:
        pv, load = PV_RATED * 0.5, 90
    return float(max(pv, 0)), float(np.clip(load, LOAD_MIN, LOAD_MAX)), grid_ok


def full_scenario_series(rng_local, dt=DT_DEC):
    n_per_seg = int(SEG_LEN / dt)
    t = []
    pv, load, gridok, seg_id = [], [], [], []
    tt = 0.0
    for si, seg in enumerate(SEGMENTS):
        for k in range(n_per_seg):
            tl = k * dt
            p, l, g = profile(seg, tl, rng_local)
            t.append(tt); pv.append(p); load.append(l); gridok.append(g); seg_id.append(si)
            tt += dt
    return dict(t=np.array(t), pv=np.array(pv), load=np.array(load),
                gridok=np.array(gridok), seg=np.array(seg_id))


# ---------------------------------------------------------------------
# 3. Reward function (Sec. IV-B of the paper) -- shared by training and
#    (for diagnostics only) evaluation.
# ---------------------------------------------------------------------
# Reward weights: FROZEN as of the Step 7 Section 6 sensitivity study
# (sim/reward_ablation.py). The original illustrative weights used W4=0.3
# (cost); the ablation found raising W4 to 1.5 simultaneously improved
# tracking RMSE (14.35->12.10 kW) and operating cost ($1.88->$1.61) at only
# a small command-smoothness penalty (7.42->8.41 kW/s), evidence the
# original cost weight was under-tuned rather than at a genuine trade-off
# optimum. Adopted here as the final, documented re-freeze -- this is now
# the production configuration for all Steps 7-13 results, not a candidate.
W1, W2, W3, W4, W5, W6 = 1.0, 5.0, 0.5, 1.5, 2.0, 0.2
DEFAULT_WEIGHTS = (W1, W2, W3, W4, W5, W6)


def ideal_pbess(pv, load, soc):
    # deficit = load - pv: positive when load exceeds generation (battery
    # should DISCHARGE, matching the positive=discharge sign convention);
    # negative when PV exceeds load (battery should CHARGE, absorb surplus).
    deficit = load - pv
    ideal = np.clip(deficit, -BESS_P, BESS_P)
    if soc <= SOC_MIN and ideal > 0:
        ideal = 0.0
    if soc >= SOC_MAX and ideal < 0:
        ideal = 0.0
    return ideal


def reward_fn(pv, load, soc, vdc_proxy, pbess_cmd, pbess_raw, pbess_prev, dt, weights=DEFAULT_WEIGHTS):
    w1, w2, w3, w4, w5, w6 = weights
    ideal = ideal_pbess(pv, load, soc)
    track = ((pbess_cmd - ideal) / BESS_P) ** 2
    soc_violation = 1.0 if (soc < SOC_MIN or soc > SOC_MAX) else 0.0
    vdc_dev = ((vdc_proxy - VDC_NOM) / VDC_NOM) ** 2
    grid_flow = max(load - 0.97 * (pv + pbess_cmd), -1e9)
    cost_rate = (PRICE_IMPORT * max(grid_flow, 0) - PRICE_EXPORT * max(-grid_flow, 0)
                 + DEGRADATION_COST * abs(pbess_cmd)) / 100.0
    limit_violation = 1.0 if abs(pbess_raw) > BESS_P else 0.0
    smoothness = ((pbess_cmd - pbess_prev) / BESS_P) ** 2
    r = -(w1 * track + w2 * soc_violation + w3 * vdc_dev + w4 * cost_rate
          + w5 * limit_violation + w6 * smoothness)
    return r


# ---------------------------------------------------------------------
# 4. Plant step (supervisory-resolution, used for training and for the
#    coarse parts of evaluation)
# ---------------------------------------------------------------------
def clamp_to_limits(p_raw, soc, dt):
    p = np.clip(p_raw, -BESS_P, BESS_P)
    # SOC feasibility clamp (can't discharge/charge past hard limits within this step)
    max_discharge_kW = max((soc - SOC_MIN) / 100.0 * BESS_E / (dt / 3600.0), 0.0)
    max_charge_kW = max((SOC_MAX - soc) / 100.0 * BESS_E / (dt / 3600.0), 0.0)
    p = np.clip(p, -max_charge_kW, max_discharge_kW)
    return p


def step_plant(state, p_raw, dt, prev_delivered):
    pv, load, soc, vdc_proxy, _ = state
    p_clamped = clamp_to_limits(p_raw, soc, dt)
    # converter slew-rate limit + small tracking error (inner PI loop realism)
    max_step = SLEW_MAX * dt
    delta = np.clip(p_clamped - prev_delivered, -max_step, max_step)
    p_target = prev_delivered + delta
    p_delivered = p_target * (1 - TRACK_ERR * np.sign(p_target) * 0)  # error modeled in fine-res eval
    # SOC update: positive p_delivered (discharge) reduces SOC
    soc_new = soc - p_delivered * dt / 3600.0 / BESS_E * 100.0
    soc_new = float(np.clip(soc_new, 0.0, 100.0))
    # bus voltage proxy (linearized static sensitivity)
    mismatch = pv + p_delivered - load
    vdc_new = VDC_NOM + KV_SENS * mismatch
    return p_delivered, soc_new, vdc_new, mismatch


# ---------------------------------------------------------------------
# 5. PI-based supervisory EMS (baseline) -- SAME state access as DQN:
#    PV, load, SOC, and bus-voltage proxy (item 3: information parity)
#
# Output pre-saturated to +-BESS_P with conditional (clamped) anti-windup:
# the integral term is only updated when doing so would NOT push the
# already-saturated output further into saturation. This is a standard
# textbook anti-windup scheme, added in response to reviewer feedback that
# an unconstrained PI baseline unfairly inflates its own pre-clamp
# limit-violation rate relative to the actuation-layer clamp. Gains
# unchanged (still hand-tuned, not optimized) -- this only fixes output
# saturation behavior, not tuning.
# ---------------------------------------------------------------------
class PIBaseline:
    def __init__(self, Kp=0.9, Ki=0.05, Ksoc=0.6, Kv=0.4):
        self.Kp, self.Ki, self.Ksoc, self.Kv = Kp, Ki, Ksoc, Kv
        self.integ = 0.0

    def act(self, pv, load, soc, vdc_proxy, dt):
        # deficit = load - pv (positive = discharge needed), matching the
        # positive=discharge / negative=charge sign convention used throughout.
        dP = load - pv
        trial_integ = np.clip(self.integ + dP * dt, -2000, 2000)
        soc_trim = self.Ksoc * (soc - 50.0) / 50.0 * BESS_P * 0.3
        vdc_trim = -self.Kv * (vdc_proxy - VDC_NOM)
        p_unclamped = self.Kp * dP + self.Ki * trial_integ / 100.0 + soc_trim + vdc_trim
        p_out = float(np.clip(p_unclamped, -BESS_P, BESS_P))
        sat_high = p_unclamped > BESS_P
        sat_low = p_unclamped < -BESS_P
        # commit the integral update only if it doesn't drive further into
        # (or isn't already driving) saturation in the same direction
        if not ((sat_high and dP > 0) or (sat_low and dP < 0)):
            self.integ = trial_integ
        return p_out


# ---------------------------------------------------------------------
# 6. DQN agent
# ---------------------------------------------------------------------
class QNet(nn.Module):
    def __init__(self, state_dim=5, n_actions=N_ACTIONS):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64), nn.ReLU(),
            nn.Linear(64, 64), nn.ReLU(),
            nn.Linear(64, n_actions),
        )

    def forward(self, x):
        return self.net(x)


def normalize_state(pv, load, soc, vdc, pbess_prev):
    return np.array([
        pv / PV_RATED,
        (load - LOAD_MIN) / (LOAD_MAX - LOAD_MIN),
        soc / 100.0,
        (vdc - VDC_NOM) / 40.0,
        pbess_prev / BESS_P,
    ], dtype=np.float32)


def train_dqn(n_episodes=260, ep_len=600, gamma=0.97, lr=1e-3,
              batch_size=128, buffer_cap=20000, target_sync=250, weights=DEFAULT_WEIGHTS,
              seed=7, verbose=True):
    torch.manual_seed(seed)
    random.seed(seed)
    qnet = QNet()
    tnet = QNet()
    tnet.load_state_dict(qnet.state_dict())
    opt = optim.Adam(qnet.parameters(), lr=lr)
    buffer = []
    eps_start, eps_end, eps_decay_eps = 1.0, 0.05, 200
    step_count = 0
    ep_returns = []

    seg_cycle = SEGMENTS
    for ep in range(n_episodes):
        eps = max(eps_end, eps_start - (eps_start - eps_end) * ep / eps_decay_eps)
        seg = seg_cycle[ep % len(seg_cycle)]
        local_rng = np.random.default_rng(1000 + ep)
        soc = float(local_rng.uniform(35, 65))
        vdc = VDC_NOM
        pbess_prev = 0.0
        ep_return = 0.0
        for k in range(ep_len):
            tl = k * DT_DEC + local_rng.uniform(-0.3, 0.3)
            pv, load, _ = profile(seg, max(tl, 0), local_rng)
            state = (pv, load, soc, vdc, pbess_prev)
            s_vec = normalize_state(*state)
            if random.random() < eps:
                a_idx = random.randrange(N_ACTIONS)
            else:
                with torch.no_grad():
                    q = qnet(torch.tensor(s_vec).unsqueeze(0))
                    a_idx = int(torch.argmax(q, dim=1).item())
            p_raw = ACTIONS[a_idx]
            p_delivered, soc_new, vdc_new, _ = step_plant(state, p_raw, DT_DEC, pbess_prev)
            r = reward_fn(pv, load, soc, vdc, p_delivered, p_raw, pbess_prev, DT_DEC, weights=weights)
            ep_return += r
            s2_vec = normalize_state(pv, load, soc_new, vdc_new, p_delivered)
            buffer.append((s_vec, a_idx, r, s2_vec))
            if len(buffer) > buffer_cap:
                buffer.pop(0)
            soc, vdc, pbess_prev = soc_new, vdc_new, p_delivered
            step_count += 1

            if len(buffer) >= batch_size and step_count % 4 == 0:
                batch = random.sample(buffer, batch_size)
                s_b = torch.tensor(np.array([b[0] for b in batch]))
                a_b = torch.tensor(np.array([b[1] for b in batch]), dtype=torch.long)
                r_b = torch.tensor(np.array([b[2] for b in batch]), dtype=torch.float32)
                s2_b = torch.tensor(np.array([b[3] for b in batch]))
                q_pred = qnet(s_b).gather(1, a_b.unsqueeze(1)).squeeze(1)
                with torch.no_grad():
                    q_next = tnet(s2_b).max(dim=1)[0]
                    q_target = r_b + gamma * q_next
                loss = nn.functional.smooth_l1_loss(q_pred, q_target)
                opt.zero_grad(); loss.backward(); opt.step()

            if step_count % target_sync == 0:
                tnet.load_state_dict(qnet.state_dict())

        ep_returns.append(ep_return)
        if verbose and (ep + 1) % 20 == 0:
            print(f"episode {ep+1}/{n_episodes}  seg={seg:16s}  return={ep_return:8.1f}  eps={eps:.2f}")

    return qnet, ep_returns


# ---------------------------------------------------------------------
# 7. Fine-resolution evaluation (dt=2ms) for both policies on the fixed
#    deterministic 5-segment scenario -- this is where DC-link ripple,
#    tracking, SOC, cost and smoothness are actually measured.
# ---------------------------------------------------------------------
FINE_SEGMENTS = {"pv_disturbance", "grid_disturbance"}  # segments where bus transients matter


def evaluate(policy_fn, label, rng_eval):
    n_fine_per_dec = int(DT_DEC / DT_FINE)
    soc = 60.0  # frozen Phase 0 initial SOC (Step 1 Sec 3.2 / Step 2 Sec 2), all Step 9-17 scenarios
    vdc = VDC_NOM
    z_integ = 0.0   # VSC voltage-loop integral state (reset per fine segment)
    pbess_prev = 0.0
    log = {k: [] for k in ["t", "pv", "load", "soc", "vdc", "pbess", "ideal", "seg", "grid"]}
    cost_total = 0.0
    limit_viol = 0
    n_dec = 0
    for si, seg in enumerate(SEGMENTS):
        n_steps = int(SEG_LEN / DT_DEC)
        do_fine = seg in FINE_SEGMENTS
        if do_fine:
            vdc, z_integ = VDC_NOM, 0.0  # start each disturbance segment at quiescent bus
        for k in range(n_steps):
            tl = k * DT_DEC
            pv, load, grid_ok = profile(seg, tl, rng_eval)
            vdc_proxy = VDC_NOM + KV_SENS * (pv + pbess_prev - load)
            p_raw = policy_fn(pv, load, soc, vdc_proxy, DT_DEC)
            if abs(p_raw) > BESS_P:
                limit_viol += 1
            p_clamped = clamp_to_limits(p_raw, soc, DT_DEC)

            if do_fine:
                # fine-resolution converter slew + 2nd-order VSC DC-bus voltage loop
                p_now = pbess_prev
                for _ in range(n_fine_per_dec):
                    max_step = SLEW_MAX * DT_FINE
                    p_now += max(-max_step, min(max_step, p_clamped - p_now))
                    p_eff = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
                    p_in_w = (pv + p_eff - load) * 1000.0
                    e = vdc - VDC_NOM
                    p_vsc_w = KP_V * e + KI_V * z_integ
                    dV = (p_in_w - p_vsc_w) / (C_BUS_EQ * vdc) * DT_FINE
                    vdc += dV
                    z_integ += e * DT_FINE
                p_delivered = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
            else:
                # supervisory-resolution converter tracking; bus assumed settled
                # (VSC loop settling time ~100 ms << 1 s decision interval)
                max_step = SLEW_MAX * DT_DEC
                p_now = pbess_prev + max(-max_step, min(max_step, p_clamped - pbess_prev))
                p_delivered = p_now * (1 - TRACK_ERR) if p_now != 0 else 0.0
                vdc = VDC_NOM

            soc = float(np.clip(soc - p_delivered * DT_DEC / 3600.0 / BESS_E * 100.0, 0, 100))

            grid_flow = load - 0.97 * (pv + p_delivered)
            if not grid_ok:
                grid_flow = 0.0  # islanded: grid cannot supply/absorb
            cost_total += DT_DEC / 3600.0 * (PRICE_IMPORT * max(grid_flow, 0)
                                              - PRICE_EXPORT * max(-grid_flow, 0)
                                              ) + DEGRADATION_COST * abs(p_delivered) * DT_DEC / 3600.0

            ideal = ideal_pbess(pv, load, soc)
            log["t"].append(si * SEG_LEN + tl); log["pv"].append(pv); log["load"].append(load)
            log["soc"].append(soc); log["vdc"].append(vdc); log["pbess"].append(p_delivered)
            log["ideal"].append(ideal); log["seg"].append(si); log["grid"].append(grid_flow)
            pbess_prev = p_delivered
            n_dec += 1

    for k in log:
        log[k] = np.array(log[k])

    track_rmse = float(np.sqrt(np.mean((log["pbess"] - log["ideal"]) ** 2)))
    soc_excursions = int(np.sum((log["soc"] < SOC_MIN) | (log["soc"] > SOC_MAX)))
    fine_seg_ids = [i for i, s in enumerate(SEGMENTS) if s in FINE_SEGMENTS]
    fine_mask = np.isin(log["seg"], fine_seg_ids)
    # per-segment tracking RMSE, to check whether the two segments evaluated with the
    # higher-fidelity fine-resolution VSC model (fine_mask) show degraded tracking
    # relative to the coarse (training-model-consistent) segments -- i.e. whether the
    # train/eval plant-model mismatch actually costs the policy anything measurable.
    seg_rmse = {}
    for i, s in enumerate(SEGMENTS):
        m = log["seg"] == i
        seg_rmse[s] = round(float(np.sqrt(np.mean((log["pbess"][m] - log["ideal"][m]) ** 2))), 2)
    coarse_rmse = float(np.sqrt(np.mean((log["pbess"][~fine_mask] - log["ideal"][~fine_mask]) ** 2)))
    fine_rmse = float(np.sqrt(np.mean((log["pbess"][fine_mask] - log["ideal"][fine_mask]) ** 2)))
    vdc_dev = log["vdc"][fine_mask] - VDC_NOM
    vdc_ripple_pct = float(np.sqrt(np.mean(vdc_dev ** 2)) / VDC_NOM * 100)
    vdc_max_dev_pct = float(np.max(np.abs(vdc_dev)) / VDC_NOM * 100)
    smooth = np.diff(log["pbess"]) / DT_DEC
    cmd_smoothness_rms = float(np.sqrt(np.mean(smooth ** 2)))
    limit_viol_pct = 100.0 * limit_viol / n_dec

    metrics = dict(
        label=label,
        power_tracking_rmse_kW=round(track_rmse, 2),
        soc_excursion_events=soc_excursions,
        soc_min=round(float(np.min(log["soc"])), 1),
        soc_max=round(float(np.max(log["soc"])), 1),
        dc_link_ripple_rms_pct=round(vdc_ripple_pct, 3),
        dc_link_max_dev_pct=round(vdc_max_dev_pct, 3),
        command_smoothness_kW_per_s=round(cmd_smoothness_rms, 2),
        limit_violation_pct=round(limit_viol_pct, 2),
        operating_cost_usd=round(float(cost_total), 2),
        seg_rmse_kW=seg_rmse,
        fine_model_segments_rmse_kW=round(fine_rmse, 2),
        coarse_model_segments_rmse_kW=round(coarse_rmse, 2),
    )
    return metrics, log


if __name__ == "__main__":
    print("Training DQN agent...")
    qnet, ep_returns = train_dqn()

    def dqn_policy(pv, load, soc, vdc_proxy, dt):
        s_vec = normalize_state(pv, load, soc, vdc_proxy, 0.0)
        with torch.no_grad():
            q = qnet(torch.tensor(s_vec).unsqueeze(0))
            a_idx = int(torch.argmax(q, dim=1).item())
        return float(ACTIONS[a_idx])

    pi = PIBaseline()

    def pi_policy(pv, load, soc, vdc_proxy, dt):
        return pi.act(pv, load, soc, vdc_proxy, dt)

    print("Evaluating PI baseline...")
    pi_metrics, pi_log = evaluate(pi_policy, "Conventional PI-based supervisory EMS", np.random.default_rng(42))
    print("Evaluating DQN policy...")
    dqn_metrics, dqn_log = evaluate(dqn_policy, "DQN-based supervisory EMS", np.random.default_rng(42))

    print(json.dumps(pi_metrics, indent=2))
    print(json.dumps(dqn_metrics, indent=2))

    np.savez("sim_results.npz",
             pi_log_t=pi_log["t"], pi_log_soc=pi_log["soc"], pi_log_vdc=pi_log["vdc"],
             pi_log_pbess=pi_log["pbess"], pi_log_ideal=pi_log["ideal"], pi_log_pv=pi_log["pv"],
             pi_log_load=pi_log["load"], pi_log_seg=pi_log["seg"],
             dqn_log_t=dqn_log["t"], dqn_log_soc=dqn_log["soc"], dqn_log_vdc=dqn_log["vdc"],
             dqn_log_pbess=dqn_log["pbess"], dqn_log_ideal=dqn_log["ideal"], dqn_log_pv=dqn_log["pv"],
             dqn_log_load=dqn_log["load"], dqn_log_seg=dqn_log["seg"],
             ep_returns=np.array(ep_returns))
    with open("sim_metrics.json", "w") as f:
        json.dump({"pi": pi_metrics, "dqn": dqn_metrics}, f, indent=2)
    print("Saved sim_results.npz and sim_metrics.json")
